<?php

namespace App\Models;

use CodeIgniter\Model;

class KunjunganModel extends Model
{
    protected $table            = 'kunjungan';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $allowedFields    = ['kode_kunjungan', 'sasaran_id', 'kegiatan_id', 'tanggal', 'status', 'catatan', 'created_by', 'created_at', 'updated_at'];
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $validationRules = [
        'sasaran_id'  => 'required|integer',
        'kegiatan_id' => 'required|integer',
        'tanggal'     => 'required|valid_date',
        'status'      => 'required|in_list[terdaftar,hadir,selesai,batal]',
    ];

    public function generateKode(): string
    {
        $prefix = 'KJ-' . date('Ymd') . '-';
        $last = $this->like('kode_kunjungan', $prefix)->orderBy('id', 'DESC')->first();
        $seq = $last ? ((int) substr($last->kode_kunjungan, -4)) + 1 : 1;
        return $prefix . str_pad($seq, 4, '0', STR_PAD_LEFT);
    }
}
