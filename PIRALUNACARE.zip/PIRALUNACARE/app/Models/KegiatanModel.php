<?php

namespace App\Models;

use CodeIgniter\Model;

class KegiatanModel extends Model
{
    protected $table            = 'kegiatan_posyandu';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $allowedFields    = ['posyandu_id', 'tanggal', 'waktu_mulai', 'waktu_selesai', 'lokasi', 'jenis_kegiatan', 'jenis_kegiatan_lain', 'keterangan', 'petugas_id', 'status', 'created_at', 'updated_at'];
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $validationRules = [
        'posyandu_id' => 'required|integer',
        'tanggal'     => 'required|valid_date',
        'status'      => 'required|in_list[direncanakan,berlangsung,selesai,dibatalkan]',
    ];
}
