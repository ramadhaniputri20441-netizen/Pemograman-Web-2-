<?php

namespace App\Models;

use CodeIgniter\Model;

class AuditLogModel extends Model
{
    protected $table            = 'audit_logs';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $allowedFields    = ['user_id', 'username', 'aksi', 'keterangan', 'tabel', 'record_id', 'ip_address', 'user_agent', 'created_at'];
    protected $useTimestamps    = false;

    public function log(string $aksi, string $keterangan = '', ?string $tabel = null, ?int $recordId = null): void
    {
        $this->insert([
            'user_id'    => session()->get('user_id'),
            'username'   => session()->get('username'),
            'aksi'       => $aksi,
            'keterangan' => $keterangan,
            'tabel'      => $tabel,
            'record_id'  => $recordId,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}
