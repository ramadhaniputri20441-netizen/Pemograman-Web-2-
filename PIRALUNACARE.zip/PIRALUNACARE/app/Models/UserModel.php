<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = ['uuid', 'name', 'email', 'username', 'password', 'phone', 'status', 'last_login_at', 'created_at', 'updated_at', 'deleted_at'];
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';
    protected $deletedField     = 'deleted_at';

    protected $validationRules = [
        'name'     => 'required|max_length[150]',
        'email'    => 'required|valid_email|max_length[150]|is_unique[users.email,id,{id}]',
        'username' => 'required|max_length[50]|is_unique[users.username,id,{id}]',
        'password' => 'required|min_length[6]',
    ];

    protected $validationMessages = [
        'email'    => ['is_unique' => 'Email sudah terdaftar.'],
        'username' => ['is_unique' => 'Username sudah terpakai.'],
    ];

    public function getRoles()
    {
        return $this->db->table('user_roles')
            ->select('roles.name, roles.label')
            ->join('roles', 'roles.id = user_roles.role_id')
            ->where('user_roles.user_id', $this->id)
            ->get()->getResult();
    }

    public function getPermissions()
    {
        return $this->db->table('role_permissions')
            ->select('permissions.name')
            ->join('permissions', 'permissions.id = role_permissions.permission_id')
            ->join('user_roles', 'user_roles.role_id = role_permissions.role_id')
            ->where('user_roles.user_id', $this->id)
            ->get()->getResult();
    }

    public function hasPermission(string $perm): bool
    {
        foreach ($this->getPermissions() as $p) {
            if ($p->name === $perm) return true;
        }
        return false;
    }

    public function hasRole(string $role): bool
    {
        foreach ($this->getRoles() as $r) {
            if ($r->name === $role) return true;
        }
        return false;
    }
}
