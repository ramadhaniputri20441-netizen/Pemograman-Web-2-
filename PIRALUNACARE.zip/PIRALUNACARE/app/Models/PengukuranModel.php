<?php

namespace App\Models;

use CodeIgniter\Model;

class PengukuranModel extends Model
{
    protected $table            = 'pengukuran';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $allowedFields    = ['kunjungan_id', 'sasaran_id', 'jenis', 'nilai', 'satuan', 'tanggal', 'petugas_id', 'catatan', 'status', 'created_at', 'updated_at'];
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $validationRules = [
        'kunjungan_id' => 'required|integer',
        'sasaran_id'   => 'required|integer',
        'jenis'        => 'required|in_list[berat_badan,tinggi_badan,panjang_badan,lingkar_lengan,lingkar_kepala,lingkar_pinggang,imt,tekanan_darah,lainnya]',
        'nilai'        => 'required|decimal',
        'satuan'       => 'required|max_length[20]',
        'tanggal'      => 'required',
    ];
}
