<?php

namespace App\Models;

use CodeIgniter\Model;

class SasaranModel extends Model
{
    protected $table            = 'sasaran';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = ['kode_sasaran', 'posyandu_id', 'nama', 'jenis_kelamin', 'tanggal_lahir', 'nik', 'no_kk', 'alamat', 'rt', 'rw', 'kelompok', 'kelompok_lain', 'telepon', 'nama_ayah', 'nama_ibu', 'status', 'catatan', 'created_by', 'created_at', 'updated_at', 'deleted_at'];
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';
    protected $deletedField     = 'deleted_at';

    protected $validationRules = [
        'kode_sasaran'  => 'required|max_length[30]|is_unique[sasaran.kode_sasaran,id,{id}]',
        'posyandu_id'   => 'required|integer',
        'nama'          => 'required|max_length[200]',
        'jenis_kelamin' => 'required|in_list[L,P]',
        'kelompok'      => 'required|in_list[balita,ibu_hamil,ibu_nifas,ibu_pasca_nifas,remaja,usia_produktif,lansia,lainnya]',
    ];

    protected $validationMessages = [
        'kode_sasaran' => ['is_unique' => 'Kode sasaran sudah digunakan.'],
    ];

    public function getUsia(): ?string
    {
        if (!$this->tanggal_lahir) return null;
        $diff = date_diff(date_create($this->tanggal_lahir), date_create('today'));
        if ($diff->y > 0) return $diff->y . ' thn';
        return $diff->m . ' bln';
    }

    public function search(string $q)
    {
        return $this->groupStart()
            ->like('nama', $q)
            ->orLike('kode_sasaran', $q)
            ->orLike('nik', $q)
            ->groupEnd()
            ->where('status', 'aktif')
            ->orderBy('nama', 'ASC')
            ->findAll();
    }
}
