<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<!-- Filter Periode -->
<div class="card">
    <div class="card-header">
        <h2>Filter Periode Laporan</h2>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a href="<?= site_url('laporan/export-kunjungan?mulai=' . $tanggalMulai . '&akhir=' . $tanggalAkhir) ?>" class="btn btn-sm">⬇ CSV Kunjungan</a>
            <a href="<?= site_url('laporan/export-pengukuran?mulai=' . $tanggalMulai . '&akhir=' . $tanggalAkhir) ?>" class="btn btn-sm">⬇ CSV Pengukuran</a>
        </div>
    </div>
    <form method="get" action="<?= site_url('laporan') ?>" class="filter-bar">
        <div>
            <label style="font-size:11px;color:var(--text-muted)">Dari</label>
            <input type="date" name="mulai" value="<?= $tanggalMulai ?>">
        </div>
        <div>
            <label style="font-size:11px;color:var(--text-muted)">Sampai</label>
            <input type="date" name="akhir" value="<?= $tanggalAkhir ?>">
        </div>
        <div>
            <label style="font-size:11px;color:var(--text-muted)">Posyandu</label>
            <select name="posyandu_id">
                <option value="">Semua</option>
                <?php foreach ($posyanduList as $p): ?>
                    <option value="<?= $p->id ?>" <?= ($posyanduId ?? '') == $p->id ? 'selected' : '' ?>><?= esc($p->nama) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label style="font-size:11px;color:var(--text-muted)">Kelompok</label>
            <select name="kelompok">
                <option value="">Semua</option>
                <?php foreach (['balita','ibu_hamil','ibu_nifas','remaja','usia_produktif','lansia'] as $k): ?>
                    <option value="<?= $k ?>" <?= ($kelompok ?? '') === $k ? 'selected' : '' ?>><?= ucwords(str_replace('_', ' ', $k)) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="align-self:flex-end">
            <button type="submit" class="btn btn-primary">Terapkan</button>
        </div>
    </form>
    <p style="font-size:12px;color:var(--text-muted)">Periode: <strong><?= date('d/m/Y', strtotime($tanggalMulai)) ?></strong> s/d <strong><?= date('d/m/Y', strtotime($tanggalAkhir)) ?></strong></p>
</div>

<!-- Ringkasan -->
<div class="stats-grid">
    <div class="stat-card"><div class="stat-value"><?= $totalSasaranAktif ?></div><div class="stat-label">Sasaran Aktif</div></div>
    <div class="stat-card accent"><div class="stat-value"><?= $totalKegiatan ?></div><div class="stat-label">Kegiatan</div></div>
    <div class="stat-card"><div class="stat-value"><?= $totalKunjungan ?></div><div class="stat-label">Total Kunjungan</div></div>
    <div class="stat-card"><div class="stat-value"><?= $totalHadir ?></div><div class="stat-label">Hadir</div></div>
</div>

<div class="grid-2col">
    <!-- Rekap per Kelompok -->
    <div class="card">
        <div class="card-header"><h2>Sasaran per Kelompok</h2></div>
        <?php if (empty($rekapKelompok)): ?>
            <p class="empty-text">Belum ada data.</p>
        <?php else: ?>
            <table class="table">
                <thead><tr><th>Kelompok</th><th style="text-align:right">Jumlah</th></tr></thead>
                <tbody>
                    <?php $max = max(array_map(fn($r) => $r->jumlah, $rekapKelompok)); ?>
                    <?php foreach ($rekapKelompok as $r): ?>
                    <tr>
                        <td><?= ucwords(str_replace('_', ' ', $r->kelompok)) ?></td>
                        <td style="text-align:right">
                            <div style="display:flex;align-items:center;gap:8px;justify-content:flex-end">
                                <div style="background:var(--primary);height:8px;border-radius:4px;width:<?= ($r->jumlah/$max)*100 ?>px;min-width:8px"></div>
                                <strong><?= $r->jumlah ?></strong>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Kunjungan per Hari -->
    <div class="card">
        <div class="card-header"><h2>Kunjungan per Hari</h2></div>
        <?php if (empty($kunjunganPerHari)): ?>
            <p class="empty-text">Tidak ada kunjungan pada periode ini.</p>
        <?php else: ?>
            <table class="table">
                <thead><tr><th>Tanggal</th><th style="text-align:right">Jumlah</th></tr></thead>
                <tbody>
                    <?php foreach ($kunjunganPerHari as $k): ?>
                    <tr>
                        <td><?= date('d/m/Y (D)', strtotime($k->tanggal)) ?></td>
                        <td style="text-align:right"><strong><?= $k->jumlah ?></strong></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<!-- Rekap Pengukuran -->
<div class="card">
    <div class="card-header"><h2>Rekap Pengukuran</h2></div>
    <?php if (empty($rekapPengukuran)): ?>
        <p class="empty-text">Tidak ada pengukuran pada periode ini.</p>
    <?php else: ?>
        <table class="table">
            <thead><tr><th>Jenis</th><th style="text-align:right">Jumlah Data</th><th style="text-align:right">Rata-rata</th></tr></thead>
            <tbody>
                <?php
                $labels = [
                    'berat_badan'=>'Berat Badan','tinggi_badan'=>'Tinggi Badan','panjang_badan'=>'Panjang Badan',
                    'lingkar_lengan'=>'LILA','lingkar_kepala'=>'Lingkar Kepala','lingkar_pinggang'=>'Lingkar Pinggang',
                    'imt'=>'IMT','tekanan_darah'=>'Tekanan Darah'
                ];
                foreach ($rekapPengukuran as $r): ?>
                <tr>
                    <td><?= $labels[$r->jenis] ?? $r->jenis ?></td>
                    <td style="text-align:right"><?= $r->jumlah ?></td>
                    <td style="text-align:right"><strong><?= number_format($r->rata, 1) ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
