<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Dashboard') ?> — PIRALUNACARE</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/app.css') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
</head>
<body>
<div class="app-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <div class="brand-icon">✚</div>
            <div class="brand-text">PIRALUNACARE</div>
        </div>
        <nav class="sidebar-nav">
            <a href="<?= site_url('dashboard') ?>" class="nav-link <?= ($title ?? '') === 'Dashboard' ? 'active' : '' ?>">
                <span class="nav-icon">🏠</span>
                <span class="nav-label">Dashboard</span>
            </a>
            <?php
            $roles = session()->get('roles') ?? [];
            $isAdmin = in_array('admin', $roles);
            $isKader = in_array('kader', $roles) || $isAdmin;
            $isPetugas = in_array('petugas_ukur', $roles) || $isAdmin;
            $isTenaga = in_array('tenaga_kesehatan', $roles) || $isAdmin;
            $isKoordinator = in_array('koordinator', $roles) || $isAdmin;

            if ($isKader): ?>
            <a href="<?= site_url('sasaran') ?>" class="nav-link <?= ($title ?? '') === 'Data Sasaran' ? 'active' : '' ?>">
                <span class="nav-icon">👥</span>
                <span class="nav-label">Data Sasaran</span>
            </a>
            <a href="<?= site_url('kegiatan') ?>" class="nav-link <?= strpos($title ?? '', 'Kegiatan') !== false ? 'active' : '' ?>">
                <span class="nav-icon">📅</span>
                <span class="nav-label">Kegiatan</span>
            </a>
            <a href="<?= site_url('registrasi') ?>" class="nav-link <?= strpos($title ?? '', 'Antrean') !== false || strpos($title ?? '', 'Registrasi') !== false ? 'active' : '' ?>">
                <span class="nav-icon">🎫</span>
                <span class="nav-label">Registrasi & Antrean</span>
            </a>
            <?php endif; ?>

            <?php if ($isPetugas): ?>
            <a href="<?= site_url('pengukuran/create?sasaran_id=') ?>" class="nav-link">
                <span class="nav-icon">📏</span>
                <span class="nav-label">Input Pengukuran</span>
            </a>
            <?php endif; ?>

            <?php if ($isTenaga || $isKoordinator || $isAdmin): ?>
            <a href="<?= site_url('laporan') ?>" class="nav-link <?= strpos($title ?? '', 'Laporan') !== false ? 'active' : '' ?>">
                <span class="nav-icon">📊</span>
                <span class="nav-label">Laporan</span>
            </a>
            <?php endif; ?>

            <?php if ($isAdmin): ?>
            <div class="nav-section">Administrator</div>
            <a href="<?= site_url('admin/pengguna') ?>" class="nav-link">
                <span class="nav-icon">👤</span>
                <span class="nav-label">Pengguna</span>
            </a>
            <a href="<?= site_url('admin/audit') ?>" class="nav-link">
                <span class="nav-icon">📋</span>
                <span class="nav-label">Audit Log</span>
            </a>
            <?php endif; ?>
        </nav>
        <div class="sidebar-footer">
            <div class="user-card">
                <div class="avatar">
                    <?= strtoupper(substr(session()->get('name') ?? 'U', 0, 1)) ?>
                </div>
                <div class="user-info">
                    <div class="user-name"><?= esc(session()->get('name') ?? '') ?></div>
                    <div class="user-role"><?= esc(implode(', ', session()->get('role_labels') ?? [])) ?></div>
                </div>
            </div>
            <a href="<?= site_url('logout') ?>" class="btn-logout">Keluar</a>
        </div>
    </aside>

    <!-- Main -->
    <div class="main-area">
        <header class="topbar">
            <button class="btn-toggle" id="toggleSidebar" aria-label="Buka menu">☰</button>
            <h1 class="page-title"><?= esc($title ?? '') ?></h1>
            <div class="topbar-right">
                <span class="today-badge">
                    <span class="dot"></span>
                    <?= date('d M Y') ?>
                </span>
            </div>
        </header>

        <main class="content">
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success" role="alert">
                    <span style="font-size:16px">✔</span>
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-error" role="alert">
                    <span style="font-size:16px">⚠</span>
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <?= $this->renderSection('content') ?>
        </main>
    </div>
</div>

<script>
document.getElementById('toggleSidebar')?.addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
});

let voicesLoaded = false;
let availableVoices = [];

window.speechSynthesis.onvoiceschanged = () => {
    availableVoices = window.speechSynthesis.getVoices();
    voicesLoaded = true;
    console.log('[PIRALUNACARE] Suara tersedia:', availableVoices.map(v => v.lang + ' (' + v.name + ')'));
};

if (window.speechSynthesis.getVoices().length > 0) {
    availableVoices = window.speechSynthesis.getVoices();
    voicesLoaded = true;
}

function pilihSuaraTerbaik() {
    if (!voicesLoaded) {
        window.speechSynthesis.getVoices();
    }
    return availableVoices.find(v => v.lang.startsWith('id') || v.lang.startsWith('in'))
        || availableVoices.find(v => v.lang.startsWith('en'))
        || availableVoices[0]
        || null;
}

function ucapkanAntrean(nomor) {
    if (!('speechSynthesis' in window)) {
        console.error('[PIRALUNACARE] Browser tidak mendukung Web Speech API');
        alert('Browser Anda tidak mendukung fitur suara.');
        return;
    }

    const teks = `Nomor antrean ${nomor}, silakan ke meja pelayanan.`;
    const ucap = new SpeechSynthesisUtterance(teks);

    const suara = pilihSuaraTerbaik();
    if (suara) {
        ucap.voice = suara;
        ucap.lang = suara.lang;
        console.log('[PIRALUNACARE] Menggunakan suara:', suara.name, '(' + suara.lang + ')');
    } else {
        console.warn('[PIRALUNACARE] Tidak ada suara tersedia, menggunakan default browser');
    }

    ucap.rate = 0.95;
    ucap.pitch = 1.05;
    ucap.volume = 1;

    ucap.onstart = () => console.log('[PIRALUNACARE] Suara mulai berbicara...');
    ucap.onend = () => console.log('[PIRALUNACARE] Suara selesai.');
    ucap.onerror = (e) => console.error('[PIRALUNACARE] Error suara:', e.error);

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(ucap);
    return ucap;
}

// Auto-ucapkan setelah klik Panggil (flashdata last_called)
<?php if (session()->getFlashdata('last_called')): ?>
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => ucapkanAntrean(<?= session()->getFlashdata('last_called') ?>), 1200);
    });
<?php endif; ?>
</script>
</body>
</html>
