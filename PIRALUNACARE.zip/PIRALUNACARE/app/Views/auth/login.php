<?= $this->extend('layout/auth') ?>

<?= $this->section('content') ?>
<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <span class="auth-logo">✚</span>
            <h1>PIRALUNACARE</h1>
            <p>Aplikasi Posyandu Digital</p>
        </div>

        <?php if (session()->getFlashdata('message')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('message') ?></div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php if (isset($errors['username'])): ?>
                    <?= esc($errors['username']) ?>
                <?php else: ?>
                    <?php foreach ($errors as $e): ?><?= esc($e) ?><br><?php endforeach; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="<?= site_url('login') ?>">
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username"
                       value="<?= esc($old['username'] ?? '') ?>"
                       placeholder="Masukkan username" required autofocus>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password"
                       placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Masuk</button>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
