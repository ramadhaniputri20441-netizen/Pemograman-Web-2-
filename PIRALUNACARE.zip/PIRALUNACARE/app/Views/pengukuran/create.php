<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<!-- Info Sasaran -->
<div class="card" style="background:linear-gradient(135deg,#f0fdfa,#ccfbf1);border-color:var(--primary)">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
        <div>
            <h2 style="margin-bottom:4px"><?= esc($sasaran->nama) ?></h2>
            <p style="color:var(--text-muted)">
                <code><?= esc($sasaran->kode_sasaran) ?></code> |
                <?= $sasaran->jenis_kelamin === 'L' ? 'Laki-laki' : 'Perempuan' ?> |
                Usia: <?php if ($sasaran->tanggal_lahir): ?><?= $usiaBulan >= 12 ? floor($usiaBulan/12) . ' thn ' . ($usiaBulan%12) . ' bln' : $usiaBulan . ' bln' ?><?php else: ?>-<?php endif; ?> |
                Kelompok: <?= ucwords(str_replace('_', ' ', $sasaran->kelompok)) ?>
            </p>
        </div>
        <div style="display:flex;gap:8px">
            <a href="<?= site_url('sasaran/' . $sasaran->id) ?>" class="btn btn-secondary">Lihat Detail</a>
            <a href="<?= site_url('sasaran') ?>" class="btn">← Sasaran</a>
        </div>
    </div>
</div>

<div class="grid-2col">
    <!-- Form Input Pengukuran -->
    <div class="card">
        <div class="card-header"><h2>Input Pengukuran Baru</h2></div>

        <form method="post" action="<?= site_url('pengukuran/store') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="sasaran_id" value="<?= $sasaran->id ?>">

            <div class="form-group">
                <label>Kunjungan *</label>
                <select name="kunjungan_id" required>
                    <option value="">— Pilih Kunjungan —</option>
                    <?php foreach ($kunjunganList as $k): ?>
                        <option value="<?= $k->id ?>" <?= ($kunjunganId ?? '') == $k->id ? 'selected' : '' ?>>
                            <?= date('d/m/Y', strtotime($k->tanggal)) ?> — <?= esc($k->kode_kunjungan) ?> (<?= ucfirst($k->status) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($kunjunganList)): ?>
                    <small style="color:var(--danger)">Belum ada kunjungan. Daftarkan sasaran ke kegiatan terlebih dahulu.</small>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Jenis Pengukuran *</label>
                <select name="jenis" id="jenisSelect" required onchange="updateSatuan()">
                    <option value="">— Pilih —</option>
                    <option value="berat_badan">Berat Badan (BB)</option>
                    <?php if ($sasaran->kelompok === 'balita'): ?>
                        <option value="tinggi_badan">Tinggi Badan (TB)</option>
                        <option value="panjang_badan">Panjang Badan (PB)</option>
                    <?php else: ?>
                        <option value="tinggi_badan">Tinggi Badan (TB)</option>
                    <?php endif; ?>
                    <option value="lingkar_lengan">Lingkar Lengan Atas (LILA)</option>
                    <option value="lingkar_kepala">Lingkar Kepala</option>
                    <option value="lingkar_pinggang">Lingkar Pinggang</option>
                    <option value="imt">IMT</option>
                    <?php if ($sasaran->kelompok === 'ibu_hamil'): ?>
                        <option value="tekanan_darah">Tekanan Darah</option>
                    <?php endif; ?>
                </select>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:0 12px">
                <div class="form-group">
                    <label>Nilai *</label>
                    <input type="number" name="nilai" step="0.01" min="0" required placeholder="0.00" id="nilaiInput">
                </div>
                <div class="form-group">
                    <label>Satuan *</label>
                    <input type="text" name="satuan" id="satuanInput" value="" required placeholder="kg/cm">
                </div>
            </div>

            <div class="form-group">
                <label>Tanggal Pengukuran *</label>
                <input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required>
            </div>

            <div class="form-group">
                <label>Catatan</label>
                <textarea name="catatan" rows="2" placeholder="Catatan tambahan (opsional)..."></textarea>
            </div>

            <div id="rangeWarning" style="display:none;background:#fef3c7;border:1px solid #fde68a;padding:8px 12px;border-radius:6px;font-size:13px;margin-bottom:12px"></div>

            <button type="submit" class="btn btn-primary btn-block">Simpan Pengukuran</button>
        </form>
    </div>

    <!-- Riwayat Pengukuran -->
    <div class="card">
        <div class="card-header"><h2>Riwayat Pengukuran</h2></div>
        <?php if (empty($riwayat)): ?>
            <p class="empty-text">Belum ada pengukuran tercatat.</p>
        <?php else: ?>
            <table class="table">
                <thead><tr><th>Tanggal</th><th>Jenis</th><th>Nilai</th><th>Status</th></tr></thead>
                <tbody>
                    <?php
                    $labels = [
                        'berat_badan'=>'Berat Badan','tinggi_badan'=>'Tinggi Badan','panjang_badan'=>'Panjang Badan',
                        'lingkar_lengan'=>'LILA','lingkar_kepala'=>'Lingkar Kepala','lingkar_pinggang'=>'Lingkar Pinggang',
                        'imt'=>'IMT','tekanan_darah'=>'Tekanan Darah','lainnya'=>'Lainnya'
                    ];
                    foreach ($riwayat as $r): ?>
                    <tr>
                        <td><?= date('d/m/Y', strtotime($r->tanggal)) ?></td>
                        <td><?= $labels[$r->jenis] ?? $r->jenis ?></td>
                        <td><strong><?= $r->nilai ?></strong> <?= esc($r->satuan) ?></td>
                        <td><span class="badge badge-<?= $r->status ?>"><?= ucfirst($r->status) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<script>
const ranges = {
    berat_badan:    {min:0.5, max:200, unit:'kg', label:'Berat Badan'},
    tinggi_badan:   {min:30,  max:250, unit:'cm', label:'Tinggi Badan'},
    panjang_badan:  {min:30,  max:120, unit:'cm', label:'Panjang Badan'},
    lingkar_lengan: {min:5,   max:60,  unit:'cm', label:'LILA'},
    lingkar_kepala: {min:20,  max:70,  unit:'cm', label:'Lingkar Kepala'},
    lingkar_pinggang:{min:20, max:200, unit:'cm', label:'Lingkar Pinggang'},
    imt:            {min:5,   max:100, unit:'kg/m²', label:'IMT'},
    tekanan_darah:  {min:40,  max:300, unit:'mmHg', label:'Tekanan Darah'},
};

function updateSatuan() {
    const jenis = document.getElementById('jenisSelect').value;
    const satuan = document.getElementById('satuanInput');
    const nilai = document.getElementById('nilaiInput');
    const warn = document.getElementById('rangeWarning');

    if (ranges[jenis]) {
        satuan.value = ranges[jenis].unit;
        nilai.max = ranges[jenis].max;
        nilai.min = ranges[jenis].min;
        warn.style.display = 'none';
    }
}

document.getElementById('nilaiInput')?.addEventListener('input', function() {
    const jenis = document.getElementById('jenisSelect').value;
    const warn = document.getElementById('rangeWarning');
    if (ranges[jenis]) {
        const v = parseFloat(this.value);
        if (v >= ranges[jenis].min && v <= ranges[jenis].max) {
            warn.style.display = 'none';
        } else {
            warn.style.display = 'block';
            warn.textContent = `⚠ Nilai di luar rentang wajar: ${ranges[jenis].min}–${ranges[jenis].max} ${ranges[jenis].unit}`;
        }
    }
});
</script>

<?= $this->endSection() ?>
