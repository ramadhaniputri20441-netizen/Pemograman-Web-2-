<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Detail Sasaran</h2>
        <div>
            <a href="<?= site_url('sasaran/' . $sasaran->id . '/edit') ?>" class="btn btn-secondary">Edit</a>
            <a href="<?= site_url('sasaran') ?>" class="btn">← Kembali</a>
        </div>
    </div>

    <div class="detail-grid">
        <div class="detail-item"><span class="dt-label">Kode</span><span class="dt-value"><code><?= esc($sasaran->kode_sasaran) ?></code></span></div>
        <div class="detail-item"><span class="dt-label">Nama</span><span class="dt-value"><?= esc($sasaran->nama) ?></span></div>
        <div class="detail-item"><span class="dt-label">Jenis Kelamin</span><span class="dt-value"><?= $sasaran->jenis_kelamin === 'L' ? 'Laki-laki' : 'Perempuan' ?></span></div>
        <div class="detail-item"><span class="dt-label">Tanggal Lahir</span><span class="dt-value"><?= $sasaran->tanggal_lahir ? date('d/m/Y', strtotime($sasaran->tanggal_lahir)) : '-' ?></span></div>
        <div class="detail-item"><span class="dt-label">Usia</span><span class="dt-value">
            <?php if ($sasaran->tanggal_lahir): $d = date_diff(date_create($sasaran->tanggal_lahir), date_create('today')); echo $d->y > 0 ? $d->y . ' tahun' : $d->m . ' bulan'; else: ?>-<?php endif; ?>
        </span></div>
        <div class="detail-item"><span class="dt-label">NIK</span><span class="dt-value"><?= esc($sasaran->nik ?: '-') ?></span></div>
        <div class="detail-item"><span class="dt-label">No. KK</span><span class="dt-value"><?= esc($sasaran->no_kk ?: '-') ?></span></div>
        <div class="detail-item"><span class="dt-label">Kelompok</span><span class="dt-value"><span class="badge"><?= ucwords(str_replace('_', ' ', $sasaran->kelompok)) ?><?= $sasaran->kelompok === 'lainnya' && $sasaran->kelompok_lain ? ' — ' . esc($sasaran->kelompok_lain) : '' ?></span></span></div>
        <div class="detail-item"><span class="dt-label">Alamat</span><span class="dt-value"><?= esc($sasaran->alamat ?: '-') ?><?= $sasaran->rt ? ' RT ' . $sasaran->rt . ' / RW ' . $sasaran->rw : '' ?></span></div>
        <div class="detail-item"><span class="dt-label">Telepon</span><span class="dt-value"><?= esc($sasaran->telepon ?: '-') ?></span></div>
        <div class="detail-item"><span class="dt-label">Nama Ayah</span><span class="dt-value"><?= esc($sasaran->nama_ayah ?: '-') ?></span></div>
        <div class="detail-item"><span class="dt-label">Nama Ibu</span><span class="dt-value"><?= esc($sasaran->nama_ibu ?: '-') ?></span></div>
        <div class="detail-item"><span class="dt-label">Status</span><span class="dt-value"><span class="badge badge-<?= $sasaran->status ?>"><?= ucfirst($sasaran->status) ?></span></span></div>
    </div>

    <?php if ($sasaran->catatan): ?>
        <div class="form-section"><h3>Catatan</h3><p><?= nl2br(esc($sasaran->catatan)) ?></p></div>
    <?php endif; ?>
</div>

<div class="grid-2col">
    <div class="card">
        <div class="card-header"><h2>Riwayat Kunjungan</h2></div>
        <?php if (empty($kunjungan)): ?>
            <p class="empty-text">Belum ada kunjungan.</p>
        <?php else: ?>
            <table class="table">
                <thead><tr><th>Kode</th><th>Tanggal</th><th>Status</th></tr></thead>
                <tbody>
                    <?php foreach ($kunjungan as $k): ?>
                    <tr>
                        <td><code><?= esc($k->kode_kunjungan) ?></code></td>
                        <td><?= date('d/m/Y', strtotime($k->tanggal)) ?></td>
                        <td><span class="badge badge-<?= $k->status ?>"><?= ucfirst($k->status) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-header"><h2>Riwayat Pengukuran</h2></div>
        <?php if (empty($pengukuran)): ?>
            <p class="empty-text">Belum ada pengukuran.</p>
        <?php else: ?>
            <table class="table">
                <thead><tr><th>Jenis</th><th>Nilai</th><th>Satuan</th><th>Tanggal</th></tr></thead>
                <tbody>
                    <?php foreach ($pengukuran as $p): ?>
                    <tr>
                        <td><?= ucwords(str_replace('_', ' ', $p->jenis)) ?></td>
                        <td><strong><?= $p->nilai ?></strong></td>
                        <td><?= esc($p->satuan) ?></td>
                        <td><?= date('d/m/Y', strtotime($p->tanggal)) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?= $this->endSection() ?>
