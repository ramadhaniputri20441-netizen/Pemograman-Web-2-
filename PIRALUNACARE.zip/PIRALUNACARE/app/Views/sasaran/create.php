<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Tambah Sasaran Baru</h2>
        <a href="<?= site_url('sasaran') ?>" class="btn btn-secondary">← Kembali</a>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $e): ?><?= esc($e) ?><br><?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('sasaran/store') ?>" id="formSasaran">
        <?= csrf_field() ?>
        <?php
        $posyanduAktif = db_connect()->table('posyandu')->where('status', 'aktif')->orderBy('id', 'ASC')->get()->getRow();
        ?>
        <input type="hidden" name="posyandu_id" value="<?= $posyanduAktif->id ?? 0 ?>">

        <div class="form-section">
            <h3>Identitas</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Kode Sasaran *</label>
                    <input type="text" name="kode_sasaran" value="<?= esc($nextKode ?? $old['kode_sasaran'] ?? '') ?>" required readonly>
                </div>
                <div class="form-group">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="nama" value="<?= esc($old['nama'] ?? '') ?>" required id="inputNama">
                    <small class="dup-warning" id="dupWarning" style="display:none;color:#dc2626;">
                        ⚠ Kemungkinan data ganda terdeteksi!
                    </small>
                </div>
                <div class="form-group">
                    <label>Jenis Kelamin *</label>
                    <select name="jenis_kelamin" required>
                        <option value="">— Pilih —</option>
                        <option value="L" <?= ($old['jenis_kelamin'] ?? '') === 'L' ? 'selected' : '' ?>>Laki-laki</option>
                        <option value="P" <?= ($old['jenis_kelamin'] ?? '') === 'P' ? 'selected' : '' ?>>Perempuan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" value="<?= esc($old['tanggal_lahir'] ?? '') ?>" id="inputTglLahir">
                </div>
                <div class="form-group">
                    <label>NIK</label>
                    <input type="text" name="nik" value="<?= esc($old['nik'] ?? '') ?>" maxlength="20">
                </div>
                <div class="form-group">
                    <label>No. KK</label>
                    <input type="text" name="no_kk" value="<?= esc($old['no_kk'] ?? '') ?>" maxlength="20">
                </div>
            </div>
        </div>

        <div class="form-section">
            <h3>Kelompok & Alamat</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Kelompok Sasaran *</label>
                    <select name="kelompok" required id="kelompokSelect" onchange="toggleKelompokLain()">
                        <option value="">— Pilih —</option>
                        <option value="balita" <?= ($old['kelompok'] ?? '') === 'balita' ? 'selected' : '' ?>>Balita</option>
                        <option value="ibu_hamil" <?= ($old['kelompok'] ?? '') === 'ibu_hamil' ? 'selected' : '' ?>>Ibu Hamil</option>
                        <option value="ibu_nifas" <?= ($old['kelompok'] ?? '') === 'ibu_nifas' ? 'selected' : '' ?>>Ibu Nifas</option>
                        <option value="ibu_pasca_nifas" <?= ($old['kelompok'] ?? '') === 'ibu_pasca_nifas' ? 'selected' : '' ?>>Ibu Pasca Nifas</option>
                        <option value="remaja" <?= ($old['kelompok'] ?? '') === 'remaja' ? 'selected' : '' ?>>Remaja</option>
                        <option value="usia_produktif" <?= ($old['kelompok'] ?? '') === 'usia_produktif' ? 'selected' : '' ?>>Usia Produktif</option>
                        <option value="lansia" <?= ($old['kelompok'] ?? '') === 'lansia' ? 'selected' : '' ?>>Lansia</option>
                        <option value="lainnya" <?= ($old['kelompok'] ?? '') === 'lainnya' ? 'selected' : '' ?>>Lainnya</option>
                    </select>
                    <div id="kelompokLainInput" style="display:none; margin-top:8px">
                        <input type="text" name="kelompok_lain" value="<?= esc($old['kelompok_lain'] ?? '') ?>" placeholder="Ketik kelompok lain..." class="form-input">
                    </div>
                </div>
                <div class="form-group">
                    <label>Telepon</label>
                    <input type="text" name="telepon" value="<?= esc($old['telepon'] ?? '') ?>" maxlength="20">
                </div>
                <div class="form-group full-width">
                    <label>Alamat</label>
                    <textarea name="alamat" rows="2"><?= esc($old['alamat'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label>RT</label>
                    <input type="text" name="rt" value="<?= esc($old['rt'] ?? '') ?>" maxlength="5">
                </div>
                <div class="form-group">
                    <label>RW</label>
                    <input type="text" name="rw" value="<?= esc($old['rw'] ?? '') ?>" maxlength="5">
                </div>
                <div class="form-group">
                    <label>Nama Ayah</label>
                    <input type="text" name="nama_ayah" value="<?= esc($old['nama_ayah'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Nama Ibu</label>
                    <input type="text" name="nama_ibu" value="<?= esc($old['nama_ibu'] ?? '') ?>">
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Simpan Sasaran</button>
            <a href="<?= site_url('sasaran') ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<script>
const namaInput = document.getElementById('inputNama');
const tglInput  = document.getElementById('inputTglLahir');
const dupWarn   = document.getElementById('dupWarning');
let debounceTimer;

function checkDuplicate() {
    const nama = namaInput.value.trim();
    const tgl  = tglInput.value;
    if (nama.length < 3 && !tgl) { dupWarn.style.display = 'none'; return; }

    fetch(`<?= site_url('sasaran/check-duplicate') ?>?nama=${encodeURIComponent(nama)}&tanggal_lahir=${tgl}`)
        .then(r => r.json())
        .then(d => { dupWarn.style.display = d.duplicate ? 'block' : 'none'; });
}

namaInput?.addEventListener('input', () => { clearTimeout(debounceTimer); debounceTimer = setTimeout(checkDuplicate, 600); });
tglInput?.addEventListener('change', checkDuplicate);

function toggleKelompokLain() {
    const select = document.getElementById('kelompokSelect');
    const inputDiv = document.getElementById('kelompokLainInput');
    const input = inputDiv.querySelector('input');
    if (select.value === 'lainnya') {
        inputDiv.style.display = 'block';
        input.required = true;
    } else {
        inputDiv.style.display = 'none';
        input.required = false;
        input.value = '';
    }
}
// Inisialisasi saat halaman dimuat
toggleKelompokLain();
</script>

<?= $this->endSection() ?>
