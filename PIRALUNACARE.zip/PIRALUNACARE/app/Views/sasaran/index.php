<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Daftar Sasaran</h2>
        <a href="<?= site_url('sasaran/create') ?>" class="btn btn-primary">+ Tambah Sasaran</a>
    </div>

    <form method="get" action="<?= site_url('sasaran') ?>" class="filter-bar">
        <input type="text" name="q" value="<?= esc($q ?? '') ?>" placeholder="Cari nama / kode / NIK...">
        <select name="kelompok">
            <option value="">Semua Kelompok</option>
            <?php foreach (['balita','ibu_hamil','ibu_nifas','ibu_pasca_nifas','remaja','usia_produktif','lansia','lainnya'] as $k): ?>
                <option value="<?= $k ?>" <?= ($kelompok ?? '') === $k ? 'selected' : '' ?>><?= ucwords(str_replace('_', ' ', $k)) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-secondary">Cari</button>
    </form>

    <?php if (empty($sasaran)): ?>
        <p class="empty-text">Tidak ada data sasaran ditemukan.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>JK</th>
                        <th>Kelompok</th>
                        <th>Usia</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sasaran as $s): ?>
                    <tr>
                        <td><code><?= esc($s->kode_sasaran) ?></code></td>
                        <td><?= esc($s->nama) ?></td>
                        <td><?= $s->jenis_kelamin ?></td>
                        <td><span class="badge"><?= ucwords(str_replace('_', ' ', $s->kelompok)) ?><?= $s->kelompok === 'lainnya' && $s->kelompok_lain ? ' — ' . esc($s->kelompok_lain) : '' ?></span></td>
                        <td>
                            <?php if ($s->tanggal_lahir): ?>
                                <?php $d = date_diff(date_create($s->tanggal_lahir), date_create('today')); ?>
                                <?= $d->y > 0 ? $d->y . ' thn' : $d->m . ' bln' ?>
                            <?php else: ?>-<?php endif; ?>
                        </td>
                        <td><span class="badge badge-<?= $s->status ?>"><?= ucfirst($s->status) ?></span></td>
                        <td>
                            <a href="<?= site_url('sasaran/' . $s->id) ?>" class="btn btn-sm">Detail</a>
                            <a href="<?= site_url('sasaran/' . $s->id . '/edit') ?>" class="btn btn-sm btn-secondary">Edit</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= $pager->links() ?>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
