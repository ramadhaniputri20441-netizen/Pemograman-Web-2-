<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Edit Sasaran — <?= esc($sasaran->nama) ?></h2>
        <a href="<?= site_url('sasaran/' . $sasaran->id) ?>" class="btn btn-secondary">← Kembali</a>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $e): ?><?= esc($e) ?><br><?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('sasaran/' . $sasaran->id . '/update') ?>">
        <?= csrf_field() ?>

        <div class="form-section">
            <h3>Identitas</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label>Kode Sasaran</label>
                    <input type="text" value="<?= esc($sasaran->kode_sasaran) ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="nama" value="<?= esc($old['nama'] ?? $sasaran->nama) ?>" required>
                </div>
                <div class="form-group">
                    <label>Jenis Kelamin *</label>
                    <select name="jenis_kelamin" required>
                        <option value="L" <?= ($old['jenis_kelamin'] ?? $sasaran->jenis_kelamin) === 'L' ? 'selected' : '' ?>>Laki-laki</option>
                        <option value="P" <?= ($old['jenis_kelamin'] ?? $sasaran->jenis_kelamin) === 'P' ? 'selected' : '' ?>>Perempuan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" value="<?= esc($old['tanggal_lahir'] ?? $sasaran->tanggal_lahir) ?>">
                </div>
                <div class="form-group">
                    <label>NIK</label>
                    <input type="text" name="nik" value="<?= esc($old['nik'] ?? $sasaran->nik) ?>" maxlength="20">
                </div>
                <div class="form-group">
                    <label>No. KK</label>
                    <input type="text" name="no_kk" value="<?= esc($old['no_kk'] ?? $sasaran->no_kk) ?>" maxlength="20">
                </div>
                <div class="form-group">
                    <label>Kelompok *</label>
                    <select name="kelompok" required id="kelompokSelectEdit" onchange="toggleKelompokLainEdit()">
                        <?php foreach (['balita'=>'Balita','ibu_hamil'=>'Ibu Hamil','ibu_nifas'=>'Ibu Nifas','ibu_pasca_nifas'=>'Ibu Pasca Nifas','remaja'=>'Remaja','usia_produktif'=>'Usia Produktif','lansia'=>'Lansia','lainnya'=>'Lainnya'] as $val=>$lbl): ?>
                            <option value="<?= $val ?>" <?= ($old['kelompok'] ?? $sasaran->kelompok) === $val ? 'selected' : '' ?>><?= $lbl ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div id="kelompokLainInputEdit" style="<?= (($old['kelompok'] ?? $sasaran->kelompok) === 'lainnya') ? 'display:block' : 'display:none'; ?> margin-top:8px">
                        <input type="text" name="kelompok_lain" value="<?= esc($old['kelompok_lain'] ?? $sasaran->kelompok_lain ?? '') ?>" placeholder="Ketik kelompok lain...">
                    </div>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="aktif" <?= ($old['status'] ?? $sasaran->status) === 'aktif' ? 'selected' : '' ?>>Aktif</option>
                        <option value="nonaktif" <?= ($old['status'] ?? $sasaran->status) === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
                    </select>
                </div>
                <div class="form-group full-width">
                    <label>Alamat</label>
                    <textarea name="alamat" rows="2"><?= esc($old['alamat'] ?? $sasaran->alamat) ?></textarea>
                </div>
                <div class="form-group"><label>RT</label><input type="text" name="rt" value="<?= esc($old['rt'] ?? $sasaran->rt) ?>" maxlength="5"></div>
                <div class="form-group"><label>RW</label><input type="text" name="rw" value="<?= esc($old['rw'] ?? $sasaran->rw) ?>" maxlength="5"></div>
                <div class="form-group"><label>Telepon</label><input type="text" name="telepon" value="<?= esc($old['telepon'] ?? $sasaran->telepon) ?>"></div>
                <div class="form-group"><label>Nama Ayah</label><input type="text" name="nama_ayah" value="<?= esc($old['nama_ayah'] ?? $sasaran->nama_ayah) ?>"></div>
                <div class="form-group"><label>Nama Ibu</label><input type="text" name="nama_ibu" value="<?= esc($old['nama_ibu'] ?? $sasaran->nama_ibu) ?>"></div>
                <div class="form-group full-width"><label>Catatan</label><textarea name="catatan" rows="2"><?= esc($old['catatan'] ?? $sasaran->catatan) ?></textarea></div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="<?= site_url('sasaran/' . $sasaran->id) ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<script>
function toggleKelompokLainEdit() {
    const select = document.getElementById('kelompokSelectEdit');
    const inputDiv = document.getElementById('kelompokLainInputEdit');
    const input = inputDiv.querySelector('input');
    if (select.value === 'lainnya') {
        inputDiv.style.display = 'block';
        input.required = true;
    } else {
        inputDiv.style.display = 'none';
        input.required = false;
        input.value = '';
    }
}
toggleKelompokLainEdit();
</script>

<?= $this->endSection() ?>
