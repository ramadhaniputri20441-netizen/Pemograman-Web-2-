<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Manajemen Pengguna</h2>
        <a href="<?= site_url('admin/pengguna/create') ?>" class="btn btn-primary">+ Tambah Pengguna</a>
    </div>

    <form method="get" action="<?= site_url('admin/pengguna') ?>" class="filter-bar">
        <input type="text" name="q" value="<?= esc($q ?? '') ?>" placeholder="Cari nama / username / email...">
        <button class="btn btn-secondary">Cari</button>
    </form>

    <table class="table">
        <thead><tr><th>Nama</th><th>Username</th><th>Email</th><th>Peran</th><th>Status</th><th>Login Terakhir</th><th>Aksi</th></tr></thead>
        <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><strong><?= esc($u->name) ?></strong></td>
                <td><?= esc($u->username) ?></td>
                <td><?= esc($u->email) ?></td>
                <td><span class="badge"><?= esc($u->role_labels ?: '-') ?></span></td>
                <td><span class="badge badge-<?= $u->status === 'active' ? 'aktif' : 'nonaktif' ?>"><?= ucfirst($u->status) ?></span></td>
                <td><?= $u->last_login_at ? date('d/m/Y H:i', strtotime($u->last_login_at)) : 'Belum pernah' ?></td>
                <td>
                    <a href="<?= site_url('admin/pengguna/' . $u->id . '/edit') ?>" class="btn btn-sm btn-secondary">Edit</a>
                    <?php if ($u->id != session()->get('user_id')): ?>
                        <a href="<?= site_url('admin/pengguna/' . $u->id . '/toggle') ?>" class="btn btn-sm"
                           onclick="return confirm('<?= $u->status === 'active' ? 'Nonaktifkan' : 'Aktifkan' ?> pengguna ini?')">
                            <?= $u->status === 'active' ? 'Nonaktifkan' : 'Aktifkan' ?>
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?= $pager->links() ?>
</div>

<?= $this->endSection() ?>
