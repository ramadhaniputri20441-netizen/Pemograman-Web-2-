<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Tambah Pengguna</h2>
        <a href="<?= site_url('admin/pengguna') ?>" class="btn btn-secondary">← Kembali</a>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error"><?php foreach ($errors as $e): ?><?= esc($e) ?><br><?php endforeach; ?></div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('admin/pengguna/store') ?>">
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="form-group"><label>Nama Lengkap *</label><input type="text" name="name" value="<?= old('name') ?>" required></div>
            <div class="form-group"><label>Username *</label><input type="text" name="username" value="<?= old('username') ?>" required></div>
            <div class="form-group"><label>Email *</label><input type="email" name="email" value="<?= old('email') ?>" required></div>
            <div class="form-group"><label>Telepon</label><input type="text" name="phone" value="<?= old('phone') ?>"></div>
            <div class="form-group"><label>Password * (min 6)</label><input type="password" name="password" required minlength="6"></div>
            <div class="form-group">
                <label>Peran *</label>
                <select name="role_id" required>
                    <option value="">— Pilih —</option>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= $r->id ?>" <?= old('role_id') == $r->id ? 'selected' : '' ?>><?= esc($r->label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status"><option value="active">Aktif</option><option value="inactive">Nonaktif</option></select>
            </div>
        </div>
        <div class="form-actions">
            <button class="btn btn-primary">Simpan Pengguna</button>
            <a href="<?= site_url('admin/pengguna') ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection() ?>
