<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Edit Pengguna — <?= esc($user->name) ?></h2>
        <a href="<?= site_url('admin/pengguna') ?>" class="btn btn-secondary">← Kembali</a>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error"><?php foreach ($errors as $e): ?><?= esc($e) ?><br><?php endforeach; ?></div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('admin/pengguna/' . $user->id . '/update') ?>">
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="form-group"><label>Nama Lengkap *</label><input type="text" name="name" value="<?= old('name', $user->name) ?>" required></div>
            <div class="form-group"><label>Username</label><input type="text" value="<?= esc($user->username) ?>" readonly style="background:var(--bg)"></div>
            <div class="form-group"><label>Email *</label><input type="email" name="email" value="<?= old('email', $user->email) ?>" required></div>
            <div class="form-group"><label>Telepon</label><input type="text" name="phone" value="<?= old('phone', $user->phone) ?>"></div>
            <div class="form-group"><label>Password Baru (kosongkan jika tidak diganti)</label><input type="password" name="password" minlength="6"></div>
            <div class="form-group">
                <label>Peran *</label>
                <select name="role_id" required>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= $r->id ?>" <?= (old('role_id', $userRole->role_id ?? 0)) == $r->id ? 'selected' : '' ?>><?= esc($r->label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="active" <?= old('status', $user->status) === 'active' ? 'selected' : '' ?>>Aktif</option>
                    <option value="inactive" <?= old('status', $user->status) === 'inactive' ? 'selected' : '' ?>>Nonaktif</option>
                </select>
            </div>
        </div>
        <div class="form-actions">
            <button class="btn btn-primary">Simpan Perubahan</button>
            <a href="<?= site_url('admin/pengguna') ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection() ?>
