<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Audit Log</h2>
        <a href="<?= site_url('admin/audit/export') ?>" class="btn btn-sm">⬇ Export CSV</a>
    </div>

    <form method="get" action="<?= site_url('admin/audit') ?>" class="filter-bar">
        <input type="text" name="q" value="<?= esc($q ?? '') ?>" placeholder="Cari username / aksi / keterangan...">
        <select name="aksi">
            <option value="">Semua Aksi</option>
            <?php foreach ($aksiList as $a): ?>
                <option value="<?= $a->aksi ?>" <?= ($aksi ?? '') === $a->aksi ? 'selected' : '' ?>><?= $a->aksi ?></option>
            <?php endforeach; ?>
        </select>
        <input type="date" name="tanggal" value="<?= esc($tanggal ?? '') ?>">
        <button class="btn btn-secondary">Filter</button>
        <?php if (($q ?? '') || ($aksi ?? '') || ($tanggal ?? '')): ?>
            <a href="<?= site_url('admin/audit') ?>" class="btn">Reset</a>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr><th>Waktu</th><th>User</th><th>Aksi</th><th>Keterangan</th><th>Objek</th><th>IP</th></tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td style="white-space:nowrap"><?= date('d/m/Y H:i:s', strtotime($log->created_at)) ?></td>
                    <td><strong><?= esc($log->username ?: '-') ?></strong></td>
                    <td><span class="badge badge-<?= str_contains($log->aksi, 'gagal') || str_contains($log->aksi, 'batal') ? 'nonaktif' : (str_contains($log->aksi, 'login') && !str_contains($log->aksi, 'gagal') ? 'aktif' : 'direncanakan') ?>"><?= esc($log->aksi) ?></span></td>
                    <td><?= esc($log->keterangan ?: '-') ?></td>
                    <td><?= $log->tabel ? '<code>' . esc($log->tabel) . '#' . ($log->record_id ?: '-') . '</code>' : '-' ?></td>
                    <td><small><?= esc($log->ip_address ?: '-') ?></small></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php
    // Manual pagination
    $totalPages = ceil($total / $perPage);
    if ($totalPages > 1):
        $params = http_build_query(array_filter(['q' => $q, 'aksi' => $aksi, 'tanggal' => $tanggal]));
    ?>
    <div class="pagination" style="margin-top:16px">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <?php $link = site_url('admin/audit?page=' . $i . ($params ? '&' . $params : '')); ?>
            <?php if ($i === $page): ?>
                <span class="current"><?= $i ?></span>
            <?php else: ?>
                <a href="<?= $link ?>"><?= $i ?></a>
            <?php endif; ?>
        <?php endfor; ?>
        <span style="border:none;background:none;color:var(--text-muted)"><?= $total ?> total</span>
    </div>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
