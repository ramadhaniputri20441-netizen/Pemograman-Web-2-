<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<!-- Pilih Kegiatan -->
<div class="card">
    <div class="card-header">
        <h2>Pilih Kegiatan</h2>
    </div>
    <form method="get" action="<?= site_url('registrasi') ?>" class="filter-bar">
        <select name="kegiatan_id" required onchange="this.form.submit()">
            <option value="">— Pilih Kegiatan —</option>
            <?php foreach ($kegiatanAktif as $k): ?>
                <option value="<?= $k->id ?>" <?= ($kegiatanId ?? '') == $k->id ? 'selected' : '' ?>>
                    <?= date('d/m/Y', strtotime($k->tanggal)) ?> — <?= esc($k->posyandu_nama) ?> (<?= ucfirst($k->status) ?>)
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-secondary">Buka</button>
    </form>

    <?php if (empty($kegiatanAktif)): ?>
        <p class="empty-text">Tidak ada kegiatan aktif. <a href="<?= site_url('kegiatan/create') ?>">Buat kegiatan baru</a></p>
    <?php endif; ?>
</div>

<?php if (!empty($kegiatan)): ?>
<!-- Antrean -->
<div class="card">
    <div class="card-header">
        <h2>Antrean — <?= esc($kegiatan->posyandu_nama) ?> (<?= date('d/m/Y', strtotime($kegiatan->tanggal)) ?>)</h2>
        <div style="display:flex;gap:8px">
            <form method="post" action="<?= site_url('registrasi/panggil') ?>" style="display:flex">
                <?= csrf_field() ?>
                <input type="hidden" name="kegiatan_id" value="<?= $kegiatan->id ?>">
                <button class="btn btn-primary">📞 Panggil Berikutnya</button>
                <button type="button" class="btn btn-outline btn-sm" style="margin-left:8px" onclick="ucapkanAntrean(1)" title="Test suara">🔊 Test Suara</button>
            </form>
        </div>
    </div>

    <?php if (empty($antrean)): ?>
        <p class="empty-text">Belum ada antrean. Daftarkan sasaran di bawah.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th style="width:50px">#</th><th>Nama</th><th>Kode</th><th>Status</th><th>Waktu</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php foreach ($antrean as $a): ?>
                    <tr style="<?= $a->status === 'sedang_dilayani' ? 'background:#fef3c7' : ($a->status === 'selesai' ? 'opacity:.6' : '') ?>">
                        <td><strong style="font-size:16px">#<?= $a->nomor ?></strong></td>
                        <td><?= esc($a->sasaran_nama) ?></td>
                        <td><code><?= esc($a->sasaran_kode ?? $a->kode_kunjungan) ?></code></td>
                        <td><span class="badge badge-<?= str_replace(' ', '_', $a->status) ?>"><?= ucfirst(str_replace('_', ' ', $a->status)) ?></span></td>
                        <td>
                            <?php if ($a->waktu_daftar): ?><small>Daftar: <?= date('H:i', strtotime($a->waktu_daftar)) ?></small><br><?php endif; ?>
                            <?php if ($a->waktu_panggil): ?><small>Panggil: <?= date('H:i', strtotime($a->waktu_panggil)) ?></small><?php endif; ?>
                        </td>
                        <td>
                            <?php if ($a->status === 'menunggu' || $a->status === 'sedang_dilayani'): ?>
                                <a href="<?= site_url('registrasi/batal/' . $a->id) ?>" class="btn btn-sm" onclick="return confirm('Batalkan?')">Batal</a>
                            <?php endif; ?>
                            <?php if ($a->status === 'menunggu'): ?>
                                <a href="<?= site_url('registrasi/selesaikan/' . $a->id) ?>" class="btn btn-sm btn-secondary" onclick="return confirm('Tandai selesai?')">✓</a>
                            <?php endif; ?>
                            <button class="btn btn-sm btn-outline" onclick="ucapkanAntrean(<?= $a->nomor ?>)" title="Ucapkan nomor antrean">🔊</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Daftarkan Sasaran -->
<div class="grid-2col">
    <div class="card">
        <div class="card-header"><h2>Daftarkan Sasaran Baru</h2></div>
        <?php if (empty($belumDaftar)): ?>
            <p class="empty-text">Semua sasaran aktif sudah terdaftar.</p>
        <?php else: ?>
            <form method="post" action="<?= site_url('registrasi/daftar') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="kegiatan_id" value="<?= $kegiatan->id ?>">
                <div class="form-group">
                    <label>Pilih Sasaran</label>
                    <select name="sasaran_id" id="selectSasaran" required>
                        <option value="">— Pilih Sasaran —</option>
                        <?php foreach ($belumDaftar as $s): ?>
                            <option value="<?= $s->id ?>"><?= esc($s->nama) ?> (<?= esc($s->kode_sasaran) ?>) — <?= ucwords(str_replace('_', ' ', $s->kelompok)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Atau Cari by Kode / Nama</label>
                    <input type="text" id="searchSasaran" placeholder="Ketik untuk filter..." oninput="filterOptions()">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Daftarkan & Buat Antrean</button>
            </form>
            <script>
            function filterOptions() {
                const q = document.getElementById('searchSasaran').value.toLowerCase();
                const sel = document.getElementById('selectSasaran');
                for (const opt of sel.options) {
                    if (!opt.value) continue;
                    opt.style.display = opt.text.toLowerCase().includes(q) ? '' : 'none';
                }
            }
            </script>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-header"><h2>Sudah Terdaftar (<?= count($sudahDaftar) ?>)</h2></div>
        <?php if (empty($sudahDaftar)): ?>
            <p class="empty-text">Belum ada yang terdaftar.</p>
        <?php else: ?>
            <table class="table">
                <thead><tr><th>Nama</th><th>Kelompok</th><th>Status</th></tr></thead>
                <tbody>
                    <?php foreach ($sudahDaftar as $k): ?>
                    <tr>
                        <td><a href="<?= site_url('sasaran/' . $k->sasaran_id) ?>"><?= esc($k->sasaran_nama) ?></a></td>
                        <td><span class="badge"><?= ucwords(str_replace('_', ' ', $k->kelompok)) ?></span></td>
                        <td><span class="badge badge-<?= $k->status ?>"><?= ucfirst($k->status) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?= $this->endSection() ?>

<script>
function filterOptions() {
    const q = document.getElementById('searchSasaran').value.toLowerCase();
    const sel = document.getElementById('selectSasaran');
    for (const opt of sel.options) {
        if (!opt.value) continue;
        opt.style.display = opt.text.toLowerCase().includes(q) ? '' : 'none';
    }
}
</script>
