<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Daftar Kegiatan Posyandu</h2>
        <a href="<?= site_url('kegiatan/create') ?>" class="btn btn-primary">+ Buat Kegiatan</a>
    </div>

    <form method="get" action="<?= site_url('kegiatan') ?>" class="filter-bar">
        <select name="status">
            <option value="">Semua Status</option>
            <?php foreach (['direncanakan','berlangsung','selesai','dibatalkan'] as $s): ?>
                <option value="<?= $s ?>" <?= ($status ?? '') === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
        </select>
        <input type="date" name="tanggal" value="<?= esc($tanggal ?? '') ?>">
        <button type="submit" class="btn btn-secondary">Filter</button>
        <?php if (($status ?? '') || ($tanggal ?? '')): ?>
            <a href="<?= site_url('kegiatan') ?>" class="btn">Reset</a>
        <?php endif; ?>
    </form>

    <?php if (empty($kegiatan)): ?>
        <p class="empty-text">Belum ada kegiatan.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Tanggal</th><th>Posyandu</th><th>Jenis</th><th>Waktu</th><th>Lokasi</th><th>Status</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($kegiatan as $k): ?>
                    <tr>
                        <td><?= date('d/m/Y', strtotime($k->tanggal)) ?></td>
                        <td><?= esc($k->posyandu_nama) ?></td>
                        <td><?= $k->jenis_kegiatan ? (ucwords(str_replace('_', ' ', $k->jenis_kegiatan)) . ($k->jenis_kegiatan === 'lainnya' && $k->jenis_kegiatan_lain ? ' — ' . esc($k->jenis_kegiatan_lain) : '')) : '-' ?></td>
                        <td><?= esc($k->waktu_mulai ?: '-') ?> <?= $k->waktu_selesai ? '- ' . esc($k->waktu_selesai) : '' ?></td>
                        <td><?= esc($k->lokasi ?: '-') ?></td>
                        <td><span class="badge badge-<?= $k->status ?>"><?= ucfirst($k->status) ?></span></td>
                        <td>
                            <a href="<?= site_url('kegiatan/' . $k->id) ?>" class="btn btn-sm">Detail</a>
                            <a href="<?= site_url('kegiatan/' . $k->id . '/edit') ?>" class="btn btn-sm btn-secondary">Edit</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= $pager->links() ?>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
