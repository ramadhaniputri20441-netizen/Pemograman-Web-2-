<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Edit Kegiatan</h2>
        <a href="<?= site_url('kegiatan/' . $kegiatan->id) ?>" class="btn btn-secondary">← Kembali</a>
    </div>

    <form method="post" action="<?= site_url('kegiatan/' . $kegiatan->id . '/update') ?>">
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="form-group">
                <label>Posyandu *</label>
                <select name="posyandu_id" required>
                    <?php foreach ($posyandu as $p): ?>
                        <option value="<?= $p->id ?>" <?= $kegiatan->posyandu_id == $p->id ? 'selected' : '' ?>><?= esc($p->nama) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Tanggal *</label>
                <input type="date" name="tanggal" value="<?= $kegiatan->tanggal ?>" required>
            </div>
            <div class="form-group"><label>Waktu Mulai</label><input type="time" name="waktu_mulai" value="<?= $kegiatan->waktu_mulai ?>"></div>
            <div class="form-group"><label>Waktu Selesai</label><input type="time" name="waktu_selesai" value="<?= $kegiatan->waktu_selesai ?>"></div>
            <div class="form-group"><label>Lokasi</label><input type="text" name="lokasi" value="<?= esc($kegiatan->lokasi) ?>"></div>
            <div class="form-group">
                <label>Jenis Kegiatan *</label>
                <select name="jenis_kegiatan" required id="jenisKegiatanSelectEdit" onchange="toggleJenisKegiatanLainEdit()">
                    <option value="">— Pilih —</option>
                    <?php
                    $jenisList = [
                        'imunisasi' => 'Imunisasi',
                        'pesan_berat_badan' => 'Pesan Berat Badan',
                        'konsultasi_kia' => 'Konsultasi KIA',
                        'vitamin_a' => 'Vitamin A',
                        'tablet_tambah_darah' => 'Tablet Tambah Darah',
                        'edukasi_gizi' => 'Edukasi Gizi',
                        'lainnya' => 'Lainnya',
                    ];
                    $selectedJenis = old('jenis_kegiatan', $kegiatan->jenis_kegiatan);
                    foreach ($jenisList as $val => $lbl): ?>
                        <option value="<?= $val ?>" <?= $selectedJenis === $val ? 'selected' : '' ?>><?= $lbl ?></option>
                    <?php endforeach; ?>
                </select>
                <div id="jenisKegiatanLainInputEdit" style="<?= ($selectedJenis === 'lainnya') ? 'display:block' : 'display:none'; ?> margin-top:8px">
                    <input type="text" name="jenis_kegiatan_lain" value="<?= esc(old('jenis_kegiatan_lain', $kegiatan->jenis_kegiatan_lain ?? '')) ?>" placeholder="Ketik jenis kegiatan lain...">
                </div>
            </div>
            <div class="form-group">
                <label>Petugas PJ</label>
                <select name="petugas_id">
                    <option value="">— Pilih —</option>
                    <?php foreach ($petugas as $u): ?>
                        <option value="<?= $u->id ?>" <?= $kegiatan->petugas_id == $u->id ? 'selected' : '' ?>><?= esc($u->name) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <?php foreach (['direncanakan','berlangsung','selesai','dibatalkan'] as $s): ?>
                        <option value="<?= $s ?>" <?= $kegiatan->status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group full-width">
                <label>Keterangan</label>
                <textarea name="keterangan" rows="2"><?= esc($kegiatan->keterangan) ?></textarea>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="<?= site_url('kegiatan/' . $kegiatan->id) ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<script>
function toggleJenisKegiatanLainEdit() {
    const select = document.getElementById('jenisKegiatanSelectEdit');
    const inputDiv = document.getElementById('jenisKegiatanLainInputEdit');
    const input = inputDiv.querySelector('input');
    if (select.value === 'lainnya') {
        inputDiv.style.display = 'block';
        input.required = true;
    } else {
        inputDiv.style.display = 'none';
        input.required = false;
        input.value = '';
    }
}
toggleJenisKegiatanLainEdit();
</script>

<?= $this->endSection() ?>
