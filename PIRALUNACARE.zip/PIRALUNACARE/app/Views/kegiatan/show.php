<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<!-- Info Kegiatan + Aksi -->
<div class="card">
    <div class="card-header">
        <h2><?= date('d/m/Y', strtotime($kegiatan->tanggal)) ?> — <?= esc($kegiatan->posyandu_nama) ?></h2>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <?php if ($kegiatan->status === 'direncanakan'): ?>
                <form method="post" action="<?= site_url('kegiatan/' . $kegiatan->id . '/status/berlangsung') ?>" style="display:inline">
                    <?= csrf_field() ?><button class="btn btn-primary">▶ Mulai Kegiatan</button>
                </form>
            <?php endif; ?>
            <?php if ($kegiatan->status === 'berlangsung'): ?>
                <form method="post" action="<?= site_url('kegiatan/' . $kegiatan->id . '/status/selesai') ?>" style="display:inline">
                    <?= csrf_field() ?><button class="btn btn-primary">✓ Selesai</button>
                </form>
            <?php endif; ?>
            <?php if ($kegiatan->status === 'direncanakan'): ?>
                <form method="post" action="<?= site_url('kegiatan/' . $kegiatan->id . '/status/dibatalkan') ?>" style="display:inline">
                    <?= csrf_field() ?><button class="btn" onclick="return confirm('Batalkan kegiatan ini?')">✗ Batalkan</button>
                </form>
            <?php endif; ?>
            <a href="<?= site_url('kegiatan/' . $kegiatan->id . '/edit') ?>" class="btn btn-secondary">Edit</a>
            <a href="<?= site_url('kegiatan') ?>" class="btn">← Kembali</a>
        </div>
    </div>

    <div class="stats-grid" style="margin-bottom:0">
        <div class="stat-card"><div class="stat-value"><?= $totalDaftar ?></div><div class="stat-label">Terdaftar</div></div>
        <div class="stat-card accent"><div class="stat-value"><?= $totalHadir ?></div><div class="stat-label">Hadir</div></div>
        <div class="stat-card"><div class="stat-value"><?= $dalamAntrean ?></div><div class="stat-label">Dalam Antrean</div></div>
        <div class="stat-card"><div class="stat-value"><span class="badge badge-<?= $kegiatan->status ?>" style="font-size:14px"><?= ucfirst($kegiatan->status) ?></span></div><div class="stat-label">Status</div></div>
    </div>

    <?php if ($kegiatan->lokasi || $kegiatan->waktu_mulai || $kegiatan->jenis_kegiatan): ?>
        <p style="margin-top:12px;color:var(--text-muted)">
            📍 <?= esc($kegiatan->lokasi ?: 'Lokasi belum ditentukan') ?>
            <?php if ($kegiatan->waktu_mulai): ?> | 🕐 <?= esc($kegiatan->waktu_mulai) ?> <?= $kegiatan->waktu_selesai ? '- ' . esc($kegiatan->waktu_selesai) : '' ?><?php endif; ?>
            <?php if ($kegiatan->jenis_kegiatan): ?> | 🏷️ <?= ucwords(str_replace('_', ' ', $kegiatan->jenis_kegiatan)) ?><?= $kegiatan->jenis_kegiatan === 'lainnya' && $kegiatan->jenis_kegiatan_lain ? ' — ' . esc($kegiatan->jenis_kegiatan_lain) : '' ?><?php endif; ?>
        </p>
    <?php endif; ?>
</div>

<!-- Antrean -->
<div class="grid-2col">
    <div class="card">
        <div class="card-header">
            <h2>Antrean Hari Ini</h2>
            <form method="post" action="<?= site_url('registrasi/panggil') ?>" style="display:flex;gap:8px">
                <?= csrf_field() ?>
                <input type="hidden" name="kegiatan_id" value="<?= $kegiatan->id ?>">
                <button class="btn btn-primary" <?= $kegiatan->status !== 'berlangsung' ? 'disabled' : '' ?>>📞 Panggil Berikutnya</button>
                <button type="button" class="btn btn-outline btn-sm" onclick="ucapkanAntrean(1)" title="Test suara">🔊 Test Suara</button>
            </form>
        </div>

        <?php if (empty($antrean)): ?>
            <p class="empty-text">Belum ada antrean.</p>
        <?php else: ?>
            <table class="table">
                <thead><tr><th>#</th><th>Nama</th><th>Status</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php foreach ($antrean as $a): ?>
                    <tr style="<?= $a->status === 'sedang_dilayani' ? 'background:#fef3c7' : '' ?>">
                        <td><strong>#<?= $a->nomor ?></strong></td>
                        <td><?= esc($a->sasaran_nama) ?><br><small style="color:var(--text-muted)"><?= esc($a->kode_sasaran) ?></small></td>
                        <td><span class="badge badge-<?= str_replace(' ', '_', $a->status) ?>"><?= ucfirst(str_replace('_', ' ', $a->status)) ?></span></td>
                        <td>
                            <?php if ($a->status === 'menunggu' || $a->status === 'sedang_dilayani'): ?>
                                <a href="<?= site_url('registrasi/batal/' . $a->id) ?>" class="btn btn-sm" onclick="return confirm('Batalkan antrean ini?')">Batal</a>
                            <?php endif; ?>
                            <button class="btn btn-sm btn-outline" onclick="ucapkanAntrean(<?= $a->nomor ?>)" title="Ucapkan nomor antrean">🔊</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Daftar Hadir -->
    <div class="card">
        <div class="card-header">
            <h2>Sudah Terdaftar (<?= count($kunjungan) ?>)</h2>
            <a href="<?= site_url('registrasi?kegiatan_id=' . $kegiatan->id) ?>" class="btn btn-sm btn-primary">+ Daftarkan</a>
        </div>
        <?php if (empty($kunjungan)): ?>
            <p class="empty-text">Belum ada pendaftar.</p>
        <?php else: ?>
            <table class="table">
                <thead><tr><th>Kode</th><th>Nama</th><th>Kelompok</th><th>Status</th></tr></thead>
                <tbody>
                    <?php foreach ($kunjungan as $k): ?>
                    <tr>
                        <td><code><?= esc($k->kode_kunjungan) ?></code></td>
                        <td><a href="<?= site_url('sasaran/' . $k->sasaran_id) ?>"><?= esc($k->sasaran_nama) ?></a></td>
                        <td><span class="badge"><?= ucwords(str_replace('_', ' ', $k->kelompok)) ?></span></td>
                        <td><span class="badge badge-<?= $k->status ?>"><?= ucfirst($k->status) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?= $this->endSection() ?>

<script>
document.getElementById('toggleSidebar')?.addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
});
</script>
