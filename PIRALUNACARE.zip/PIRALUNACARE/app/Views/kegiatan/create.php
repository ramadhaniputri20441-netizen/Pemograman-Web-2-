<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="card">
    <div class="card-header">
        <h2>Buat Kegiatan Baru</h2>
        <a href="<?= site_url('kegiatan') ?>" class="btn btn-secondary">← Kembali</a>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error"><?php foreach ($errors as $e): ?><?= esc($e) ?><br><?php endforeach; ?></div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('kegiatan/store') ?>">
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="form-group">
                <label>Posyandu *</label>
                <select name="posyandu_id" required>
                    <option value="">— Pilih —</option>
                    <?php foreach ($posyandu as $p): ?>
                        <option value="<?= $p->id ?>" <?= (old('posyandu_id') ?? '') == $p->id ? 'selected' : '' ?>><?= esc($p->nama) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Tanggal *</label>
                <input type="date" name="tanggal" value="<?= old('tanggal') ?: date('Y-m-d') ?>" required>
            </div>
            <div class="form-group">
                <label>Waktu Mulai</label>
                <input type="time" name="waktu_mulai" value="<?= old('waktu_mulai') ?>">
            </div>
            <div class="form-group">
                <label>Waktu Selesai</label>
                <input type="time" name="waktu_selesai" value="<?= old('waktu_selesai') ?>">
            </div>
            <div class="form-group">
                <label>Lokasi</label>
                <input type="text" name="lokasi" value="<?= old('lokasi') ?>" placeholder="Contoh: Balai RW 03">
            </div>
            <div class="form-group">
                <label>Jenis Kegiatan *</label>
                <select name="jenis_kegiatan" required id="jenisKegiatanSelect" onchange="toggleJenisKegiatanLain()">
                    <option value="">— Pilih —</option>
                    <option value="imunisasi" <?= old('jenis_kegiatan') === 'imunisasi' ? 'selected' : '' ?>>Imunisasi</option>
                    <option value="pesan_berat_badan" <?= old('jenis_kegiatan') === 'pesan_berat_badan' ? 'selected' : '' ?>>Pesan Berat Badan</option>
                    <option value="konsultasi_kia" <?= old('jenis_kegiatan') === 'konsultasi_kia' ? 'selected' : '' ?>>Konsultasi KIA</option>
                    <option value="vitamin_a" <?= old('jenis_kegiatan') === 'vitamin_a' ? 'selected' : '' ?>>Vitamin A</option>
                    <option value="tablet_tambah_darah" <?= old('jenis_kegiatan') === 'tablet_tambah_darah' ? 'selected' : '' ?>>Tablet Tambah Darah</option>
                    <option value="edukasi_gizi" <?= old('jenis_kegiatan') === 'edukasi_gizi' ? 'selected' : '' ?>>Edukasi Gizi</option>
                    <option value="lainnya" <?= old('jenis_kegiatan') === 'lainnya' ? 'selected' : '' ?>>Lainnya</option>
                </select>
                <div id="jenisKegiatanLainInput" style="display:none; margin-top:8px">
                    <input type="text" name="jenis_kegiatan_lain" value="<?= old('jenis_kegiatan_lain') ?>" placeholder="Ketik jenis kegiatan lain...">
                </div>
            </div>
            <div class="form-group">
                <label>Petugas Penanggung Jawab</label>
                <select name="petugas_id">
                    <option value="">— Pilih —</option>
                    <?php foreach ($petugas as $u): ?>
                        <option value="<?= $u->id ?>" <?= (old('petugas_id') ?? '') == $u->id ? 'selected' : '' ?>><?= esc($u->name) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="direncanakan" selected>Direncanakan</option>
                    <option value="berlangsung">Berlangsung</option>
                </select>
            </div>
            <div class="form-group full-width">
                <label>Keterangan</label>
                <textarea name="keterangan" rows="2" placeholder="Catatan tambahan..."><?= old('keterangan') ?></textarea>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Simpan Kegiatan</button>
            <a href="<?= site_url('kegiatan') ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<script>
function toggleJenisKegiatanLain() {
    const select = document.getElementById('jenisKegiatanSelect');
    const inputDiv = document.getElementById('jenisKegiatanLainInput');
    const input = inputDiv.querySelector('input');
    if (select.value === 'lainnya') {
        inputDiv.style.display = 'block';
        input.required = true;
    } else {
        inputDiv.style.display = 'none';
        input.required = false;
        input.value = '';
    }
}
toggleJenisKegiatanLain();
</script>

<?= $this->endSection() ?>
