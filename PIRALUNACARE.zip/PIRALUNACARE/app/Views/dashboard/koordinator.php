<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<!-- Hero Welcome Koordinator -->
<div class="card" style="border:none; box-shadow:none; padding:0; margin-bottom:0;">
    <div style="background: linear-gradient(135deg, var(--accent) 0%, #f59e0b 100%); border-radius: var(--radius); padding: 34px 36px; color: #fff; margin-bottom: 36px; position: relative; overflow: hidden;">
        <div style="position:absolute; right:-40px; top:-40px; width:160px; height:160px; background: rgba(255,255,255,.12); border-radius: 50%; filter: blur(20px);"></div>
        <div style="position:relative; z-index:2;">
            <div style="font-size:11px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; opacity:.85; margin-bottom:8px; display:flex; align-items:center; gap:8px;">
                <span style="width:6px;height:6px;background:#fff;border-radius:50%;animation:pulse 2s infinite"></span>
                Koordinator
            </div>
            <h1 style="font-size:30px; font-weight:900; margin-bottom:6px;">Monitoring Kegiatan</h1>
            <p style="opacity:.9; font-size:14px;">Pantau kelengkapan data, rekap kegiatan, dan laporan periode Posyandu.</p>
        </div>
    </div>
</div>

<!-- Quick Actions Koordinator -->
<div class="card">
    <div class="card-header">
        <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:20px">⚡</span>
            <h2>Aksi Koordinator</h2>
        </div>
    </div>
    <div class="action-grid">
        <a href="<?= site_url('laporan') ?>" class="action-card">
            <div class="action-icon">📊</div>
            <div class="action-label">Lihat Laporan</div>
        </a>
        <a href="<?= site_url('kegiatan') ?>" class="action-card">
            <div class="action-icon">📅</div>
            <div class="action-label">Kelola Kegiatan</div>
        </a>
        <a href="<?= site_url('sasaran') ?>" class="action-card">
            <div class="action-icon">👥</div>
            <div class="action-label">Data Sasaran</div>
        </a>
        <a href="<?= site_url('registrasi') ?>" class="action-card">
            <div class="action-icon">🎫</div>
            <div class="action-label">Registrasi & Antrean</div>
        </a>
    </div>
</div>

<!-- Stats Koordinator -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-value"><?= $totalSasaran ?? 0 ?></div>
        <div class="stat-label">Sasaran Aktif</div>
    </div>
    <div class="stat-card success">
        <div class="stat-value"><?= $totalKegiatan ?? 0 ?></div>
        <div class="stat-label">Total Kegiatan</div>
    </div>
    <div class="stat-card warning">
        <div class="stat-value"><?= $totalKunjungan ?? 0 ?></div>
        <div class="stat-label">Total Kunjungan</div>
    </div>
    <div class="stat-card info">
        <div class="stat-value"><?= count($kegiatanHari ?? []) ?></div>
        <div class="stat-label">Kegiatan Hari Ini</div>
    </div>
</div>

<!-- Rekap per Kelompok -->
<div class="card">
    <div class="card-header"><h2>Sasaran per Kelompok</h2></div>
    <?php if (empty($rekapKelompok ?? [])): ?>
        <p class="empty-text">Belum ada data sasaran.</p>
    <?php else: ?>
        <table class="table">
            <thead><tr><th>Kelompok</th><th style="text-align:right">Jumlah</th><th style="text-align:right">Persentase</th></tr></thead>
            <tbody>
                <?php $totalS = array_sum(array_column($rekapKelompok, 'jumlah')); ?>
                <?php foreach ($rekapKelompok as $r): ?>
                <tr>
                    <td><?= ucwords(str_replace('_', ' ', $r->kelompok)) ?></td>
                    <td style="text-align:right"><strong><?= $r->jumlah ?></strong></td>
                    <td style="text-align:right"><?= $totalS > 0 ? number_format(($r->jumlah / $totalS) * 100, 1) : 0 ?>%</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- Status Kegiatan -->
<div class="card">
    <div class="card-header"><h2>Status Kegiatan</h2></div>
    <table class="table">
        <thead><tr><th>Status</th><th style="text-align:right">Jumlah</th></tr></thead>
        <tbody>
            <?php
            $statusLabels = [
                'direncanakan' => 'Direncanakan',
                'berlangsung' => 'Berlangsung',
                'selesai' => 'Selesai',
                'dibatalkan' => 'Dibatalkan',
            ];
            $statusColors = [
                'direncanakan' => 'badge-direncanakan',
                'berlangsung' => 'badge-berlangsung',
                'selesai' => 'badge-selesai',
                'dibatalkan' => 'badge-nonaktif',
            ];
            foreach ($kegiatanStatus ?? [] as $status => $jumlah): ?>
            <tr>
                <td><span class="badge <?= $statusColors[$status] ?? 'badge-direncanakan' ?>"><?= $statusLabels[$status] ?? $status ?></span></td>
                <td style="text-align:right"><strong><?= $jumlah ?></strong></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
