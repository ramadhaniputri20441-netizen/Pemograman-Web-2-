<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<!-- Hero Welcome Kader -->
<div class="card" style="border:none; box-shadow:none; padding:0; margin-bottom:0;">
    <div style="background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%); border-radius: var(--radius); padding: 34px 36px; color: #fff; margin-bottom: 36px; position: relative; overflow: hidden;">
        <div style="position:absolute; right:-40px; top:-40px; width:160px; height:160px; background: rgba(255,255,255,.12); border-radius: 50%; filter: blur(20px);"></div>
        <div style="position:relative; z-index:2;">
            <div style="font-size:11px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; opacity:.85; margin-bottom:8px; display:flex; align-items:center; gap:8px;">
                <span style="width:6px;height:6px;background:#fff;border-radius:50%;animation:pulse 2s infinite"></span>
                Kader Posyandu
            </div>
            <h1 style="font-size:30px; font-weight:900; margin-bottom:6px;">Pendaftaran & Kehadiran</h1>
            <p style="opacity:.9; font-size:14px;">Daftarkan sasaran, catat kehadiran, dan kelola antrean pelayanan Posyandu.</p>
        </div>
    </div>
</div>

<!-- Quick Actions Kader -->
<div class="card">
    <div class="card-header">
        <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:20px">⚡</span>
            <h2>Aksi Kader</h2>
        </div>
    </div>
    <div class="action-grid">
        <a href="<?= site_url('sasaran/create') ?>" class="action-card">
            <div class="action-icon">👤</div>
            <div class="action-label">Tambah Sasaran</div>
        </a>
        <a href="<?= site_url('sasaran') ?>" class="action-card">
            <div class="action-icon">📋</div>
            <div class="action-label">Data Sasaran</div>
        </a>
        <a href="<?= site_url('registrasi') ?>" class="action-card">
            <div class="action-icon">🎫</div>
            <div class="action-label">Registrasi & Antrean</div>
        </a>
        <a href="<?= site_url('kegiatan/create') ?>" class="action-card">
            <div class="action-icon">📅</div>
            <div class="action-label">Buat Kegiatan</div>
        </a>
    </div>
</div>

<!-- Stats Kader -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-value"><?= $totalSasaran ?? 0 ?></div>
        <div class="stat-label">Sasaran Terdaftar</div>
    </div>
    <div class="stat-card success">
        <div class="stat-value"><?= $totalKegiatan ?? 0 ?></div>
        <div class="stat-label">Total Kegiatan</div>
    </div>
    <div class="stat-card warning">
        <div class="stat-value"><?= $totalKunjungan ?? 0 ?></div>
        <div class="stat-label">Total Kunjungan</div>
    </div>
    <div class="stat-card info">
        <div class="stat-value"><?= count($kegiatanHari ?? []) ?></div>
        <div class="stat-label">Kegiatan Hari Ini</div>
    </div>
</div>

<!-- Sasaran Terbaru -->
<div class="card">
    <div class="card-header">
        <h2>Sasaran Terbaru</h2>
        <a href="<?= site_url('sasaran') ?>" class="btn btn-sm btn-outline">Lihat Semua</a>
    </div>
    <?php if (empty($sasaranTerbaru ?? [])): ?>
        <p class="empty-text">Belum ada data sasaran.</p>
    <?php else: ?>
        <table class="table">
            <thead><tr><th>Kode</th><th>Nama</th><th>Kelompok</th><th>Usia</th></tr></thead>
            <tbody>
                <?php foreach ($sasaranTerbaru as $s): ?>
                <tr>
                    <td><code><?= esc($s->kode_sasaran) ?></code></td>
                    <td><?= esc($s->nama) ?></td>
                    <td><span class="badge"><?= ucwords(str_replace('_', ' ', $s->kelompok)) ?></span></td>
                    <td>
                        <?php if ($s->tanggal_lahir): ?>
                            <?php $d = date_diff(date_create($s->tanggal_lahir), date_create('today')); ?>
                            <?= $d->y > 0 ? $d->y . ' thn' : $d->m . ' bln' ?>
                        <?php else: ?>-<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- Kegiatan Hari Ini -->
<div class="card">
    <div class="card-header"><h2>Kegiatan Hari Ini</h2></div>
    <?php if (empty($kegiatanHari ?? [])): ?>
        <p class="empty-text">Tidak ada kegiatan hari ini.</p>
    <?php else: ?>
        <table class="table">
            <thead><tr><th>Waktu</th><th>Lokasi</th><th>Status</th></tr></thead>
            <tbody>
                <?php foreach ($kegiatanHari as $k): ?>
                <tr>
                    <td><?= esc($k->waktu_mulai ?: '-') ?></td>
                    <td><?= esc($k->lokasi ?: '-') ?></td>
                    <td><span class="badge badge-<?= $k->status ?>"><?= ucfirst($k->status) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
