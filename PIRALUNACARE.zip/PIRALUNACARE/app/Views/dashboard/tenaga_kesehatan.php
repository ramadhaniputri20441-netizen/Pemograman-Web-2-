<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<!-- Hero Welcome Tenaga Kesehatan -->
<div class="card" style="border:none; box-shadow:none; padding:0; margin-bottom:0;">
    <div style="background: linear-gradient(135deg, var(--info) 0%, #2563eb 100%); border-radius: var(--radius); padding: 34px 36px; color: #fff; margin-bottom: 36px; position: relative; overflow: hidden;">
        <div style="position:absolute; right:-40px; top:-40px; width:160px; height:160px; background: rgba(255,255,255,.12); border-radius: 50%; filter: blur(20px);"></div>
        <div style="position:relative; z-index:2;">
            <div style="font-size:11px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; opacity:.85; margin-bottom:8px; display:flex; align-items:center; gap:8px;">
                <span style="width:6px;height:6px;background:#fff;border-radius:50%;animation:pulse 2s infinite"></span>
                Tenaga Kesehatan
            </div>
            <h1 style="font-size:30px; font-weight:900; margin-bottom:6px;">Pemeriksaan & Tindakan</h1>
            <p style="opacity:.9; font-size:14px;">Tinjau data sasaran, catat pemeriksaan, dan kelola rujukan ke FKTP.</p>
        </div>
    </div>
</div>

<!-- Quick Actions Tenaga Kesehatan -->
<div class="card">
    <div class="card-header">
        <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:20px">⚡</span>
            <h2>Aksi Tenaga Kesehatan</h2>
        </div>
    </div>
    <div class="action-grid">
        <a href="<?= site_url('sasaran') ?>" class="action-card">
            <div class="action-icon">👥</div>
            <div class="action-label">Data Sasaran</div>
        </a>
        <a href="<?= site_url('laporan') ?>" class="action-card">
            <div class="action-icon">📊</div>
            <div class="action-label">Lihat Laporan</div>
        </a>
        <a href="<?= site_url('registrasi') ?>" class="action-card">
            <div class="action-icon">🎫</div>
            <div class="action-label">Antrean Hari Ini</div>
        </a>
        <a href="<?= site_url('kegiatan') ?>" class="action-card">
            <div class="action-icon">📅</div>
            <div class="action-label">Kegiatan</div>
        </a>
    </div>
</div>

<!-- Stats Tenaga Kesehatan -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-value"><?= $totalSasaran ?? 0 ?></div>
        <div class="stat-label">Sasaran Terdaftar</div>
    </div>
    <div class="stat-card success">
        <div class="stat-value"><?= $totalKunjungan ?? 0 ?></div>
        <div class="stat-label">Total Kunjungan</div>
    </div>
    <div class="stat-card warning">
        <div class="stat-value"><?= $sasaranButuhValidasi ?? 0 ?></div>
        <div class="stat-label">Butuh Validasi</div>
    </div>
    <div class="stat-card info">
        <div class="stat-value"><?= count($kegiatanHari ?? []) ?></div>
        <div class="stat-label">Kegiatan Hari Ini</div>
    </div>
</div>

<!-- Riwayat Pengukuran Terbaru -->
<div class="card">
    <div class="card-header">
        <h2>Pengukuran Terbaru</h2>
        <a href="<?= site_url('sasaran') ?>" class="btn btn-sm btn-outline">Lihat Semua</a>
    </div>
    <?php if (empty($pengukuranTerbaru ?? [])): ?>
        <p class="empty-text">Belum ada data pengukuran.</p>
    <?php else: ?>
        <table class="table">
            <thead><tr><th>Tanggal</th><th>Sasaran</th><th>Jenis</th><th>Nilai</th><th>Satuan</th></tr></thead>
            <tbody>
                <?php
                $jenisLabels = [
                    'berat_badan' => 'Berat Badan',
                    'tinggi_badan' => 'Tinggi Badan',
                    'panjang_badan' => 'Panjang Badan',
                    'lingkar_lengan' => 'LILA',
                    'lingkar_kepala' => 'Lingkar Kepala',
                    'imt' => 'IMT',
                    'tekanan_darah' => 'Tekanan Darah',
                ];
                foreach ($pengukuranTerbaru as $p): ?>
                <tr>
                    <td><?= date('d/m/Y', strtotime($p->tanggal)) ?></td>
                    <td><?= esc($p->nama ?: '-') ?></td>
                    <td><?= $jenisLabels[$p->jenis ?? 'lainnya'] ?? ucwords(str_replace('_', ' ', $p->jenis ?? 'lainnya')) ?></td>
                    <td><strong><?= $p->nilai ?></strong> <?= esc($p->satuan) ?></td>
                    <td><span class="badge badge-<?= $p->status ?>"><?= ucfirst($p->status) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
