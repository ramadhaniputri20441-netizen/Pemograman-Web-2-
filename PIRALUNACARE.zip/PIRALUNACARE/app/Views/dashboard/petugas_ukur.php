<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<!-- Hero Welcome Petugas Pengukuran -->
<div class="card" style="border:none; box-shadow:none; padding:0; margin-bottom:0;">
    <div style="background: linear-gradient(135deg, var(--success) 0%, #16a34a 100%); border-radius: var(--radius); padding: 34px 36px; color: #fff; margin-bottom: 36px; position: relative; overflow: hidden;">
        <div style="position:absolute; right:-40px; top:-40px; width:160px; height:160px; background: rgba(255,255,255,.12); border-radius: 50%; filter: blur(20px);"></div>
        <div style="position:relative; z-index:2;">
            <div style="font-size:11px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; opacity:.85; margin-bottom:8px; display:flex; align-items:center; gap:8px;">
                <span style="width:6px;height:6px;background:#fff;border-radius:50%;animation:pulse 2s infinite"></span>
                Petugas Pengukuran
            </div>
            <h1 style="font-size:30px; font-weight:900; margin-bottom:6px;">Input Pengukuran</h1>
            <p style="opacity:.9; font-size:14px;">Catat berat badan, tinggi badan, LILA, dan pengukuran lain untuk sasaran Posyandu.</p>
        </div>
    </div>
</div>

<!-- Quick Actions Petugas Pengukuran -->
<div class="card">
    <div class="card-header">
        <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:20px">⚡</span>
            <h2>Aksi Petugas Pengukuran</h2>
        </div>
    </div>
    <div class="action-grid">
        <a href="<?= site_url('sasaran') ?>" class="action-card">
            <div class="action-icon">👥</div>
            <div class="action-label">Pilih Sasaran</div>
        </a>
        <a href="<?= site_url('registrasi') ?>" class="action-card">
            <div class="action-icon">🎫</div>
            <div class="action-label">Antrean Hari Ini</div>
        </a>
        <a href="<?= site_url('pengukuran/create?sasaran_id=') ?>" class="action-card">
            <div class="action-icon">📏</div>
            <div class="action-label">Input Pengukuran</div>
        </a>
        <a href="<?= site_url('sasaran?kelompok=balita') ?>" class="action-card">
            <div class="action-icon">👶</div>
            <div class="action-label">Sasaran Balita</div>
        </a>
    </div>
</div>

<!-- Stats Petugas Pengukuran -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-value"><?= $totalSasaran ?? 0 ?></div>
        <div class="stat-label">Sasaran Aktif</div>
    </div>
    <div class="stat-card success">
        <div class="stat-value"><?= $totalKunjungan ?? 0 ?></div>
        <div class="stat-label">Total Kunjungan</div>
    </div>
    <div class="stat-card warning">
        <div class="stat-value"><?= $sasaranButuhPengukuran ?? 0 ?></div>
        <div class="stat-label">Butuh Pengukuran</div>
    </div>
    <div class="stat-card info">
        <div class="stat-value"><?= count($kegiatanHari ?? []) ?></div>
        <div class="stat-label">Kegiatan Hari Ini</div>
    </div>
</div>

<!-- Panduan Pengukuran -->
<div class="card">
    <div class="card-header"><h2>Panduan Pengukuran</h2></div>
    <div class="grid-3col">
        <div class="card" style="padding:20px; text-align:center; border:none; box-shadow:none;">
            <div style="font-size:32px; margin-bottom:10px">⚖️</div>
            <div style="font-weight:700">Berat Badan</div>
            <div style="font-size:13px; color:var(--text-muted)">Satuan: kg</div>
        </div>
        <div class="card" style="padding:20px; text-align:center; border:none; box-shadow:none;">
            <div style="font-size:32px; margin-bottom:10px">📏</div>
            <div style="font-weight:700">Tinggi Badan</div>
            <div style="font-size:13px; color:var(--text-muted)">Satuan: cm</div>
        </div>
        <div class="card" style="padding:20px; text-align:center; border:none; box-shadow:none;">
            <div style="font-size:32px; margin-bottom:10px">📐</div>
            <div style="font-weight:700">LILA</div>
            <div style="font-size:13px; color:var(--text-muted)">Satuan: cm</div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
