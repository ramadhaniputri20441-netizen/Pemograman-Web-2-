<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\Encryption\Handlers\BaseHandler;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // ---- Roles ----
        $roles = [
            ['name' => 'admin',          'label' => 'Administrator',       'description' => 'Mengelola akun, konfigurasi, data master, audit'],
            ['name' => 'kader',          'label' => 'Kader Posyandu',      'description' => 'Pendaftaran sasaran, kehadiran, antrean'],
            ['name' => 'petugas_ukur',   'label' => 'Petugas Pengukuran',  'description' => 'Mencatat berat badan, tinggi badan, pengukuran lain'],
            ['name' => 'tenaga_kesehatan','label' => 'Tenaga Kesehatan',   'description' => 'Meninjau data, catatan pemeriksaan, rujukan'],
            ['name' => 'koordinator',     'label' => 'Koordinator Posyandu','description' => 'Memantau kegiatan, laporan periode'],
        ];
        $roleIds = [];
        foreach ($roles as $r) {
            $this->db->table('roles')->insert($r);
            $roleIds[$r['name']] = $this->db->insertID();
        }

        // ---- Permissions ----
        $permissions = [
            ['name' => 'users.manage',       'label' => 'Kelola Pengguna',         'module' => 'admin'],
            ['name' => 'roles.manage',       'label' => 'Kelola Peran',            'module' => 'admin'],
            ['name' => 'master.manage',      'label' => 'Kelola Data Master',      'module' => 'admin'],
            ['name' => 'audit.view',         'label' => 'Lihat Audit Log',         'module' => 'admin'],
            ['name' => 'sasaran.create',     'label' => 'Tambah Sasaran',          'module' => 'sasaran'],
            ['name' => 'sasaran.update',     'label' => 'Ubah Sasaran',            'module' => 'sasaran'],
            ['name' => 'sasaran.view',       'label' => 'Lihat Sasaran',           'module' => 'sasaran'],
            ['name' => 'kegiatan.manage',    'label' => 'Kelola Kegiatan',         'module' => 'kegiatan'],
            ['name' => 'antrean.manage',     'label' => 'Kelola Antrean',          'module' => 'antrean'],
            ['name' => 'pengukuran.create',  'label' => 'Input Pengukuran',        'module' => 'pengukuran'],
            ['name' => 'pengukuran.view',    'label' => 'Lihat Pengukuran',        'module' => 'pengukuran'],
            ['name' => 'pelayanan.create',   'label' => 'Input Pelayanan',         'module' => 'pelayanan'],
            ['name' => 'pelayanan.view',     'label' => 'Lihat Pelayanan',         'module' => 'pelayanan'],
            ['name' => 'pelayanan.finalize', 'label' => 'Finalisasi Pelayanan',    'module' => 'pelayanan'],
            ['name' => 'rujukan.create',     'label' => 'Buat Rujukan',            'module' => 'rujukan'],
            ['name' => 'rujukan.view',       'label' => 'Lihat Rujukan',           'module' => 'rujukan'],
            ['name' => 'laporan.view',       'label' => 'Lihat Laporan',           'module' => 'laporan'],
            ['name' => 'laporan.export',     'label' => 'Ekspor Laporan',          'module' => 'laporan'],
        ];
        $permIds = [];
        foreach ($permissions as $p) {
            $this->db->table('permissions')->insert($p);
            $permIds[$p['name']] = $this->db->insertID();
        }

        // ---- Role → Permission mapping ----
        $map = [
            'admin' => array_keys($permIds),
            'kader' => ['sasaran.create', 'sasaran.update', 'sasaran.view', 'kegiatan.manage', 'antrean.manage', 'pengukuran.create', 'pengukuran.view', 'pelayanan.create', 'pelayanan.view'],
            'petugas_ukur' => ['sasaran.view', 'pengukuran.create', 'pengukuran.view'],
            'tenaga_kesehatan' => ['sasaran.view', 'pengukuran.view', 'pelayanan.view', 'pelayanan.create', 'pelayanan.finalize', 'rujukan.create', 'rujukan.view'],
            'koordinator' => ['sasaran.view', 'pengukuran.view', 'pelayanan.view', 'rujukan.view', 'laporan.view', 'laporan.export', 'audit.view'],
        ];
        foreach ($map as $roleName => $permNames) {
            foreach ($permNames as $pn) {
                if (isset($permIds[$pn])) {
                    $this->db->table('role_permissions')->insert([
                        'role_id'       => $roleIds[$roleName],
                        'permission_id' => $permIds[$pn],
                    ]);
                }
            }
        }

        // ---- Posyandu ----
        $this->db->table('posyandu')->insert([
            'kode'       => 'PSY-001',
            'nama'       => 'Posyandu Melati 1',
            'alamat'     => 'Jl. Merdeka No. 10',
            'desa'       => 'Sukamaju',
            'kecamatan'  => 'Cibinong',
            'kabupaten'  => 'Bogor',
            'provinsi'   => 'Jawa Barat',
            'status'     => 'aktif',
        ]);
        $posyanduId = $this->db->insertID();

        // ---- Admin User ----
        $pepper = env('encryption.pepper', '');
        $hasher = \CodeIgniter\Encryption\Handlers\BaseHandler::class;
        $password = password_hash('admin123' . $pepper, PASSWORD_DEFAULT);

        $this->db->table('users')->insert([
            'uuid'     => sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000, mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)),
            'name'     => 'Administrator',
            'email'    => 'admin@piralunacare.local',
            'username' => 'admin',
            'password' => $password,
            'status'   => 'active',
        ]);
        $userId = $this->db->insertID();

        $this->db->table('user_roles')->insert([
            'user_id' => $userId,
            'role_id' => $roleIds['admin'],
        ]);

        echo "Seeder selesai: roles, permissions, posyandu, admin.\n";
        echo "Login → username: admin / password: admin123\n";
    }
}
