<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SeedContohPengguna extends Seeder
{
    public function run()
    {
        $db = db_connect();

        // Ambil role IDs
        $roles = $db->table('roles')->get()->getResult();
        $roleMap = [];
        foreach ($roles as $r) {
            $roleMap[$r->name] = $r->id;
        }

        $posyanduId = $db->table('posyandu')->where('status', 'aktif')->get()->getRow()->id ?? 1;

        $users = [
            [
                'name'     => 'Siti Aminah',
                'username' => 'siti',
                'email'    => 'siti@piralunacare.local',
                'password' => password_hash('siti123', PASSWORD_DEFAULT),
                'phone'    => '081234567890',
                'status'   => 'active',
                'role'     => 'kader',
            ],
            [
                'name'     => 'Budi Santoso, S.Kep',
                'username' => 'budi',
                'email'    => 'budi@piralunacare.local',
                'password' => password_hash('budi123', PASSWORD_DEFAULT),
                'phone'    => '081234567891',
                'status'   => 'active',
                'role'     => 'petugas_ukur',
            ],
            [
                'name'     => 'Dewi Lestari, S.Keb',
                'username' => 'dewi',
                'email'    => 'dewi@piralunacare.local',
                'password' => password_hash('dewi123', PASSWORD_DEFAULT),
                'phone'    => '081234567892',
                'status'   => 'active',
                'role'     => 'tenaga_kesehatan',
            ],
            [
                'name'     => 'Rina Marlina',
                'username' => 'rina',
                'email'    => 'rina@piralunacare.local',
                'password' => password_hash('rina123', PASSWORD_DEFAULT),
                'phone'    => '081234567893',
                'status'   => 'active',
                'role'     => 'koordinator',
            ],
        ];

        foreach ($users as $u) {
            // Skip jika username atau email sudah ada
            $exists = $db->table('users')->where('username', $u['username'])->orWhere('email', $u['email'])->countAllResults();
            if ($exists > 0) {
                echo "Lewati: {$u['name']} (sudah ada)\n";
                continue;
            }

            $db->table('users')->insert([
                'uuid'       => sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0x0fff)|0x4000, mt_rand(0,0x3fff)|0x8000, mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff)),
                'name'       => $u['name'],
                'email'      => $u['email'],
                'username'   => $u['username'],
                'password'   => $u['password'],
                'phone'      => $u['phone'],
                'status'     => $u['status'],
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            $userId = $db->insertID();

            $db->table('user_roles')->insert([
                'user_id'   => $userId,
                'role_id'   => $roleMap[$u['role']] ?? 1,
                'created_at'=> date('Y-m-d H:i:s'),
            ]);

            echo "Dibuat: {$u['name']} ({$u['role']}) - username: {$u['username']}\n";
        }

        echo "\nSemua pengguna contoh telah ditambahkan.\n";
    }
}
