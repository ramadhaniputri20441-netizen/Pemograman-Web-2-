<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateTindakLanjut extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kunjungan_id'  => ['type' => 'INT', 'unsigned' => true],
            'sasaran_id'    => ['type' => 'INT', 'unsigned' => true],
            'jenis'         => ['type' => 'ENUM', 'constraint' => ['edukasi', 'pemantauan', 'imunisasi', 'tablet_tambah_darah', 'pemberian_vitamin', 'lainnya']],
            'keterangan'    => ['type' => 'TEXT'],
            'jadwal_ulang'  => ['type' => 'DATE', 'null' => true],
            'petugas_id'    => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'status'        => ['type' => 'ENUM', 'constraint' => ['belum', 'sedang', 'selesai'], 'default' => 'belum'],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('kunjungan_id');
        $this->forge->addKey('sasaran_id');
        $this->forge->addForeignKey('kunjungan_id', 'kunjungan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('sasaran_id', 'sasaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('petugas_id', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('tindak_lanjut', true);
    }

    public function down()
    {
        $this->forge->dropTable('tindak_lanjut', true);
    }
}
