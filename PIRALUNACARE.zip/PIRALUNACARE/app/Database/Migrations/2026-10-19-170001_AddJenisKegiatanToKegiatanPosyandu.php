<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddJenisKegiatanToKegiatanPosyandu extends Migration
{
    public function up()
    {
        $this->forge->addColumn('kegiatan_posyandu', [
            'jenis_kegiatan'      => ['type' => 'ENUM', 'constraint' => ['imunisasi', 'pesan_berat_badan', 'konsultasi_kia', 'vitamin_a', 'tablet_tambah_darah', 'edukasi_gizi', 'lainnya'], 'default' => 'lainnya', 'after' => 'lokasi'],
            'jenis_kegiatan_lain' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true, 'after' => 'jenis_kegiatan'],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('kegiatan_posyandu', ['jenis_kegiatan', 'jenis_kegiatan_lain']);
    }
}
