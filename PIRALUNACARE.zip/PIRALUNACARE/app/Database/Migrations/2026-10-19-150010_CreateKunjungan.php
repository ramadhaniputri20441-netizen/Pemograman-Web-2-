<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateKunjungan extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kode_kunjungan' => ['type' => 'VARCHAR', 'constraint' => 30],
            'sasaran_id'    => ['type' => 'INT', 'unsigned' => true],
            'kegiatan_id'   => ['type' => 'INT', 'unsigned' => true],
            'tanggal'       => ['type' => 'DATE'],
            'status'        => ['type' => 'ENUM', 'constraint' => ['terdaftar', 'hadir', 'selesai', 'batal'], 'default' => 'terdaftar'],
            'catatan'       => ['type' => 'TEXT', 'null' => true],
            'created_by'    => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('kode_kunjungan');
        $this->forge->addKey('sasaran_id');
        $this->forge->addKey('kegiatan_id');
        $this->forge->addKey('tanggal');
        $this->forge->addForeignKey('sasaran_id', 'sasaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kegiatan_id', 'kegiatan_posyandu', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('created_by', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('kunjungan', true);
    }

    public function down()
    {
        $this->forge->dropTable('kunjungan', true);
    }
}
