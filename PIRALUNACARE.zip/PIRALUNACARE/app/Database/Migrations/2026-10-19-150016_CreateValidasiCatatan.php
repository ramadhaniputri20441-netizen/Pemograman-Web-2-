<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateValidasiCatatan extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'              => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'catatan_id'      => ['type' => 'INT', 'unsigned' => true],
            'validator_id'    => ['type' => 'INT', 'unsigned' => true],
            'status'          => ['type' => 'ENUM', 'constraint' => ['disetujui', 'ditolak', 'dikoreksi'], 'default' => 'disetujui'],
            'keterangan'      => ['type' => 'TEXT', 'null' => true],
            'alasan_koreksi'  => ['type' => 'TEXT', 'null' => true],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('catatan_id');
        $this->forge->addForeignKey('catatan_id', 'catatan_pelayanan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('validator_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('validasi_catatan', true);
    }

    public function down()
    {
        $this->forge->dropTable('validasi_catatan', true);
    }
}
