<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePengukuran extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kunjungan_id'  => ['type' => 'INT', 'unsigned' => true],
            'sasaran_id'    => ['type' => 'INT', 'unsigned' => true],
            'jenis'         => ['type' => 'ENUM', 'constraint' => ['berat_badan', 'tinggi_badan', 'panjang_badan', 'lingkar_lengan', 'lingkar_kepala', 'lingkar_pinggang', 'imt', 'tekanan_darah', 'lainnya']],
            'nilai'         => ['type' => 'DECIMAL', 'constraint' => '8,2'],
            'satuan'        => ['type' => 'VARCHAR', 'constraint' => 20],
            'tanggal'       => ['type' => 'DATETIME'],
            'petugas_id'    => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'catatan'       => ['type' => 'TEXT', 'null' => true],
            'status'        => ['type' => 'ENUM', 'constraint' => ['draf', 'lengkap', 'diverifikasi', 'dikoreksi'], 'default' => 'draf'],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('kunjungan_id');
        $this->forge->addKey('sasaran_id');
        $this->forge->addKey('jenis');
        $this->forge->addForeignKey('kunjungan_id', 'kunjungan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('sasaran_id', 'sasaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('petugas_id', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('pengukuran', true);
    }

    public function down()
    {
        $this->forge->dropTable('pengukuran', true);
    }
}
