<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePosyandu extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kode'        => ['type' => 'VARCHAR', 'constraint' => 20],
            'nama'        => ['type' => 'VARCHAR', 'constraint' => 150],
            'alamat'      => ['type' => 'TEXT', 'null' => true],
            'desa'        => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'kecamatan'   => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'kabupaten'   => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'provinsi'    => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'telepon'     => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'status'      => ['type' => 'ENUM', 'constraint' => ['aktif', 'nonaktif'], 'default' => 'aktif'],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('kode');
        $this->forge->createTable('posyandu', true);
    }

    public function down()
    {
        $this->forge->dropTable('posyandu', true);
    }
}
