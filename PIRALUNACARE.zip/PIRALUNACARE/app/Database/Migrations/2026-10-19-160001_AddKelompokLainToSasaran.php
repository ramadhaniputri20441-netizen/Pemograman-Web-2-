<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddKelompokLainToSasaran extends Migration
{
    public function up()
    {
        $this->forge->addColumn('sasaran', [
            'kelompok_lain' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true, 'after' => 'kelompok'],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('sasaran', 'kelompok_lain');
    }
}
