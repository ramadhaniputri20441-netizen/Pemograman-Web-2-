<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateCatatanPelayanan extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kunjungan_id'  => ['type' => 'INT', 'unsigned' => true],
            'sasaran_id'    => ['type' => 'INT', 'unsigned' => true],
            'jenis_layanan' => ['type' => 'VARCHAR', 'constraint' => 100],
            'isi_catatan'   => ['type' => 'TEXT'],
            'petugas_id'    => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'waktu_catat'   => ['type' => 'DATETIME'],
            'status'        => ['type' => 'ENUM', 'constraint' => ['draf', 'belum_lengkap', 'lengkap', 'dikoreksi', 'final'], 'default' => 'draf'],
            'finalized_at'  => ['type' => 'DATETIME', 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('kunjungan_id');
        $this->forge->addKey('sasaran_id');
        $this->forge->addKey('status');
        $this->forge->addForeignKey('kunjungan_id', 'kunjungan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('sasaran_id', 'sasaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('petugas_id', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('catatan_pelayanan', true);
    }

    public function down()
    {
        $this->forge->dropTable('catatan_pelayanan', true);
    }
}
