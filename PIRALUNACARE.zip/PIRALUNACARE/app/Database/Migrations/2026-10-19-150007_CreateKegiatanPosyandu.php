<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateKegiatanPosyandu extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'posyandu_id'  => ['type' => 'INT', 'unsigned' => true],
            'tanggal'      => ['type' => 'DATE'],
            'waktu_mulai'  => ['type' => 'TIME', 'null' => true],
            'waktu_selesai'=> ['type' => 'TIME', 'null' => true],
            'lokasi'       => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'keterangan'   => ['type' => 'TEXT', 'null' => true],
            'petugas_id'   => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'status'       => ['type' => 'ENUM', 'constraint' => ['direncanakan', 'berlangsung', 'selesai', 'dibatalkan'], 'default' => 'direncanakan'],
            'created_at'   => ['type' => 'DATETIME', 'null' => true],
            'updated_at'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('posyandu_id');
        $this->forge->addKey('tanggal');
        $this->forge->addForeignKey('posyandu_id', 'posyandu', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('petugas_id', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('kegiatan_posyandu', true);
    }

    public function down()
    {
        $this->forge->dropTable('kegiatan_posyandu', true);
    }
}
