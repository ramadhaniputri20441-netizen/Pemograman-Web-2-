<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateRujukan extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kode_rujukan'  => ['type' => 'VARCHAR', 'constraint' => 30],
            'kunjungan_id'  => ['type' => 'INT', 'unsigned' => true],
            'sasaran_id'    => ['type' => 'INT', 'unsigned' => true],
            'alasan'        => ['type' => 'TEXT'],
            'tujuan'        => ['type' => 'VARCHAR', 'constraint' => 200],
            'tingkat'       => ['type' => 'ENUM', 'constraint' => ['puskesmas', 'klinik', 'rumah_sakit', 'spesialis'], 'default' => 'puskesmas'],
            'tanggal'       => ['type' => 'DATE'],
            'status'        => ['type' => 'ENUM', 'constraint' => ['diajukan', 'diterima', 'selesai', 'batal'], 'default' => 'diajukan'],
            'petugas_id'    => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'catatan_balik' => ['type' => 'TEXT', 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('kode_rujukan');
        $this->forge->addKey('sasaran_id');
        $this->forge->addForeignKey('kunjungan_id', 'kunjungan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('sasaran_id', 'sasaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('petugas_id', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('rujukan', true);
    }

    public function down()
    {
        $this->forge->dropTable('rujukan', true);
    }
}
