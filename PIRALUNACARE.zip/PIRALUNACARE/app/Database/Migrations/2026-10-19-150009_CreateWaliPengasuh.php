<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateWaliPengasuh extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'sasaran_id'    => ['type' => 'INT', 'unsigned' => true],
            'nama'          => ['type' => 'VARCHAR', 'constraint' => 200],
            'hubungan'      => ['type' => 'ENUM', 'constraint' => ['ayah', 'ibu', 'wali', 'kakek', 'nenek', 'saudara', 'lainnya'], 'default' => 'ibu'],
            'telepon'       => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'nik'           => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'pekerjaan'     => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'alamat'        => ['type' => 'TEXT', 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('sasaran_id');
        $this->forge->addForeignKey('sasaran_id', 'sasaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('wali_pengasuh', true);
    }

    public function down()
    {
        $this->forge->dropTable('wali_pengasuh', true);
    }
}
