<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSasaran extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'             => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kode_sasaran'   => ['type' => 'VARCHAR', 'constraint' => 30],
            'posyandu_id'    => ['type' => 'INT', 'unsigned' => true],
            'nama'           => ['type' => 'VARCHAR', 'constraint' => 200],
            'jenis_kelamin'  => ['type' => 'ENUM', 'constraint' => ['L', 'P']],
            'tanggal_lahir'  => ['type' => 'DATE', 'null' => true],
            'nik'            => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'no_kk'          => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'alamat'         => ['type' => 'TEXT', 'null' => true],
            'rt'             => ['type' => 'VARCHAR', 'constraint' => 5, 'null' => true],
            'rw'             => ['type' => 'VARCHAR', 'constraint' => 5, 'null' => true],
            'kelompok'       => ['type' => 'ENUM', 'constraint' => ['balita', 'ibu_hamil', 'ibu_nifas', 'ibu_pasca_nifas', 'remaja', 'usia_produktif', 'lansia', 'lainnya'], 'default' => 'balita'],
            'telepon'        => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'nama_ayah'      => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'nama_ibu'       => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'status'         => ['type' => 'ENUM', 'constraint' => ['aktif', 'nonaktif'], 'default' => 'aktif'],
            'catatan'        => ['type' => 'TEXT', 'null' => true],
            'created_by'     => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
            'deleted_at'     => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('kode_sasaran');
        $this->forge->addKey('posyandu_id');
        $this->forge->addKey('nama');
        $this->forge->addKey('kelompok');
        $this->forge->addForeignKey('posyandu_id', 'posyandu', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('created_by', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('sasaran', true);
    }

    public function down()
    {
        $this->forge->dropTable('sasaran', true);
    }
}
