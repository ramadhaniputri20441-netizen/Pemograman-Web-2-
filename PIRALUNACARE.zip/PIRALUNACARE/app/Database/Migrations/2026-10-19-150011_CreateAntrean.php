<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateAntrean extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kunjungan_id' => ['type' => 'INT', 'unsigned' => true],
            'kegiatan_id'  => ['type' => 'INT', 'unsigned' => true],
            'nomor'        => ['type' => 'INT', 'unsigned' => true],
            'status'       => ['type' => 'ENUM', 'constraint' => ['menunggu', 'sedang_dilayani', 'selesai', 'batal'], 'default' => 'menunggu'],
            'waktu_daftar' => ['type' => 'DATETIME', 'null' => true],
            'waktu_panggil'=> ['type' => 'DATETIME', 'null' => true],
            'waktu_selesai'=> ['type' => 'DATETIME', 'null' => true],
            'meja'         => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'   => ['type' => 'DATETIME', 'null' => true],
            'updated_at'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey(['kunjungan_id', 'kegiatan_id']);
        $this->forge->addKey('kegiatan_id');
        $this->forge->addForeignKey('kunjungan_id', 'kunjungan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kegiatan_id', 'kegiatan_posyandu', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('antrean', true);
    }

    public function down()
    {
        $this->forge->dropTable('antrean', true);
    }
}
