<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

// ---- Auth ----
$routes->get('/',            'AuthController::login',   ['filter' => 'guest']);
$routes->get('login',        'AuthController::login',   ['filter' => 'guest']);
$routes->post('login',       'AuthController::attempt', ['filter' => 'guest']);
$routes->get('logout',       'AuthController::logout',  ['filter' => 'auth']);

// ---- Dashboard ----
$routes->get('dashboard',    'DashboardController::index', ['filter' => 'auth']);

// ---- Sasaran ----
$routes->group('sasaran', ['filter' => 'auth'], function ($routes) {
    $routes->get('',                 'SasaranController::index');
    $routes->get('create',           'SasaranController::create');
    $routes->post('store',           'SasaranController::store');
    $routes->get('check-duplicate',  'SasaranController::checkDuplicate');
    $routes->get('(:num)',           'SasaranController::show/$1');
    $routes->get('(:num)/edit',      'SasaranController::edit/$1');
    $routes->post('(:num)/update',   'SasaranController::update/$1');
    $routes->post('(:num)/destroy',  'SasaranController::destroy/$1');
});

// ---- Kegiatan ----
$routes->group('kegiatan', ['filter' => 'auth'], function ($routes) {
    $routes->get('',                          'KegiatanController::index');
    $routes->get('create',                    'KegiatanController::create');
    $routes->post('store',                    'KegiatanController::store');
    $routes->get('(:num)',                    'KegiatanController::show/$1');
    $routes->get('(:num)/edit',               'KegiatanController::edit/$1');
    $routes->post('(:num)/update',            'KegiatanController::update/$1');
    $routes->post('(:num)/status/(:segment)', 'KegiatanController::changeStatus/$1/$2');
});

// ---- Registrasi & Antrean ----
$routes->group('registrasi', ['filter' => 'auth'], function ($routes) {
    $routes->get('',                    'RegistrasiController::index');
    $routes->post('daftar',             'RegistrasiController::daftar');
    $routes->post('panggil',            'RegistrasiController::panggil');
    $routes->get('batal/(:num)',        'RegistrasiController::batal/$1');
    $routes->get('selesaikan/(:num)',   'RegistrasiController::selesaikan/$1');
});

// ---- Pengukuran ----
$routes->group('pengukuran', ['filter' => 'auth'], function ($routes) {
    $routes->get('create',              'PengukuranController::create');
    $routes->post('store',              'PengukuranController::store');
    $routes->post('(:num)/verifikasi',  'PengukuranController::verifikasi/$1');
});

// ---- Laporan ----
$routes->group('laporan', ['filter' => 'auth'], function ($routes) {
    $routes->get('',                    'LaporanController::index');
    $routes->get('export-kunjungan',    'LaporanController::exportKunjungan');
    $routes->get('export-pengukuran',   'LaporanController::exportPengukuran');
});

// ---- Admin (hanya admin) ----
$routes->group('admin', ['filter' => 'admin'], function ($routes) {
    // Pengguna
    $routes->group('pengguna', function ($routes) {
        $routes->get('',                    'AdminPenggunaController::index');
        $routes->get('create',              'AdminPenggunaController::create');
        $routes->post('store',              'AdminPenggunaController::store');
        $routes->get('(:num)/edit',         'AdminPenggunaController::edit/$1');
        $routes->post('(:num)/update',      'AdminPenggunaController::update/$1');
        $routes->get('(:num)/toggle',       'AdminPenggunaController::toggleStatus/$1');
    });

    // Audit
    $routes->group('audit', function ($routes) {
        $routes->get('',        'AdminAuditController::index');
        $routes->get('export',  'AdminAuditController::export');
    });
});
