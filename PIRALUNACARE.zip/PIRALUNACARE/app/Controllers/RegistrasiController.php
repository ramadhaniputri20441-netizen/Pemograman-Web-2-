<?php

namespace App\Controllers;

use App\Models\KunjunganModel;
use App\Models\KegiatanModel;
use App\Models\SasaranModel;
use App\Models\AuditLogModel;

class RegistrasiController extends BaseController
{
    protected $kunjungan;
    protected $audit;

    public function __construct()
    {
        $this->kunjungan = new KunjunganModel();
        $this->audit     = new AuditLogModel();
    }

    /**
     * Halaman utama: pilih kegiatan → kelola registrasi & antrean
     */
    public function index()
    {
        $db = db_connect();
        $kegiatanId = $this->request->getGet('kegiatan_id');

        $kegiatanAktif = $db->table('kegiatan_posyandu')
            ->select('kegiatan_posyandu.*, posyandu.nama as posyandu_nama')
            ->join('posyandu', 'posyandu.id = kegiatan_posyandu.posyandu_id')
            ->whereIn('kegiatan_posyandu.status', ['direncanakan', 'berlangsung'])
            ->orderBy('tanggal', 'DESC')
            ->get()->getResult();

        $data = [
            'title'        => 'Registrasi & Antrean',
            'kegiatanAktif'=> $kegiatanAktif,
            'kegiatanId'   => $kegiatanId,
        ];

        if ($kegiatanId) {
            $kegiatan = $db->table('kegiatan_posyandu')
                ->select('kegiatan_posyandu.*, posyandu.nama as posyandu_nama')
                ->join('posyandu', 'posyandu.id = kegiatan_posyandu.posyandu_id')
                ->where('kegiatan_posyandu.id', $kegiatanId)
                ->get()->getRow();

            $sudahDaftar = $db->table('kunjungan')
                ->select('kunjungan.*, sasaran.nama as sasaran_nama, sasaran.kode_sasaran, sasaran.kelompok')
                ->join('sasaran', 'sasaran.id = kunjungan.sasaran_id')
                ->where('kunjungan.kegiatan_id', $kegiatanId)
                ->orderBy('kunjungan.created_at', 'ASC')
                ->get()->getResult();

            $antrean = $db->table('antrean')
                ->select('antrean.*, kunjungan.kode_kunjungan, sasaran.nama as sasaran_nama, sasaran.kode_sasaran')
                ->join('kunjungan', 'kunjungan.id = antrean.kunjungan_id')
                ->join('sasaran', 'sasaran.id = kunjungan.sasaran_id')
                ->where('antrean.kegiatan_id', $kegiatanId)
                ->orderBy('antrean.nomor', 'ASC')
                ->get()->getResult();

            // Sasaran belum terdaftar (aktif)
            $sudahId = array_column($sudahDaftar, 'sasaran_id');
            $builder = $db->table('sasaran')->where('status', 'aktif');
            if ($sudahId) $builder->whereNotIn('id', $sudahId);
            $belumDaftar = $builder->orderBy('nama')->get()->getResult();

            $data['kegiatan']   = $kegiatan;
            $data['sudahDaftar']= $sudahDaftar;
            $data['antrean']    = $antrean;
            $data['belumDaftar']= $belumDaftar;
        }

        return view('registrasi/index', $data);
    }

    /**
     * Daftarkan sasaran ke kegiatan → buat kunjungan + nomor antrean
     */
    public function daftar()
    {
        $sasaranId  = $this->request->getPost('sasaran_id');
        $kegiatanId = $this->request->getPost('kegiatan_id');

        if (!$sasaranId || !$kegiatanId) {
            return redirect()->back()->with('error', 'Data tidak lengkap.');
        }

        // Cek duplikat kunjungan
        $existing = db_connect()->table('kunjungan')
            ->where('sasaran_id', $sasaranId)
            ->where('kegiatan_id', $kegiatanId)
            ->countAllResults();

        if ($existing > 0) {
            return redirect()->back()->with('error', 'Sasaran sudah terdaftar pada kegiatan ini.');
        }

        // Buat kunjungan
        $kunjunganId = $this->kunjungan->insert([
            'kode_kunjungan' => $this->kunjungan->generateKode(),
            'sasaran_id'     => $sasaranId,
            'kegiatan_id'    => $kegiatanId,
            'tanggal'        => date('Y-m-d'),
            'status'         => 'hadir',
            'created_by'     => session()->get('user_id'),
        ]);

        // Buat antrean
        $lastNo = db_connect()->table('antrean')
            ->where('kegiatan_id', $kegiatanId)
            ->selectMax('nomor')
            ->get()->getRow();
        $nextNo = ($lastNo->nomor ?? 0) + 1;

        db_connect()->table('antrean')->insert([
            'kunjungan_id' => $kunjunganId,
            'kegiatan_id'  => $kegiatanId,
            'nomor'        => $nextNo,
            'status'       => 'menunggu',
            'waktu_daftar' => date('Y-m-d H:i:s'),
            'created_at'   => date('Y-m-d H:i:s'),
        ]);

        $sasaran = db_connect()->table('sasaran')->where('id', $sasaranId)->get()->getRow();
        $this->audit->log('registrasi', "Mendaftarkan {$sasaran->nama} (antrean #{$nextNo}) ke kegiatan #{$kegiatanId}", 'kunjungan', $kunjunganId);

        return redirect()->to('/registrasi?kegiatan_id=' . $kegiatanId)->with('success', "Berhasil didaftarkan! Nomor antrean: {$nextNo}");
    }

    /**
     * Panggil antrean berikutnya
     */
    public function panggil()
    {
        $kegiatanId = $this->request->getPost('kegiatan_id');
        if (!$kegiatanId) return redirect()->back()->with('error', 'Kegiatan tidak dipilih.');

        $db = db_connect();

        // Set sedang_dilayani yang sebelumnya jadi selesai
        $db->table('antrean')
            ->where('kegiatan_id', $kegiatanId)
            ->where('status', 'sedang_dilayani')
            ->update(['status' => 'selesai', 'waktu_selesai' => date('Y-m-d H:i:s')]);

        // Ambil berikutnya (menunggu, nomor terkecil)
        $berikut = $db->table('antrean')
            ->where('kegiatan_id', $kegiatanId)
            ->where('status', 'menunggu')
            ->orderBy('nomor', 'ASC')
            ->limit(1)
            ->get()->getRow();

        if (!$berikut) {
            return redirect()->back()->with('error', 'Tidak ada antrean menunggu.');
        }

        $db->table('antrean')
            ->where('id', $berikut->id)
            ->update(['status' => 'sedang_dilayani', 'waktu_panggil' => date('Y-m-d H:i:s')]);

        $this->audit->log('panggil_antrean', "Memanggil antrean #{$berikut->nomor} pada kegiatan {$kegiatanId}", 'antrean', $berikut->id);

        return redirect()->back()->with('last_called', $berikut->nomor)->with('success', "Memanggil nomor antrean: {$berikut->nomor}");
    }

    /**
     * Batalkan antrean
     */
    public function batal($antreanId)
    {
        $db = db_connect();
        $antrean = $db->table('antrean')->where('id', $antreanId)->get()->getRow();
        if (!$antrean) return redirect()->back()->with('error', 'Antrean tidak ditemukan.');

        $db->table('antrean')->where('id', $antreanId)->update(['status' => 'batal', 'updated_at' => date('Y-m-d H:i:s')]);
        $this->audit->log('batal_antrean', "Membatalkan antrean #{$antrean->nomor}", 'antrean', $antreanId);

        return redirect()->back()->with('success', 'Antrean dibatalkan.');
    }

    /**
     * Tandai selesai tanpa panggil (skip)
     */
    public function selesaikan($antreanId)
    {
        $db = db_connect();
        $antrean = $db->table('antrean')->where('id', $antreanId)->get()->getRow();
        if (!$antrean) return redirect()->back()->with('error', 'Antrean tidak ditemukan.');

        $db->table('antrean')->where('id', $antreanId)->update([
            'status' => 'selesai', 'waktu_selesai' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')
        ]);

        return redirect()->back()->with('success', 'Antrean ditandai selesai.');
    }
}
