<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\AuditLogModel;

class AuthController extends BaseController
{
    protected $userModel;
    protected $audit;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->audit     = new AuditLogModel();
    }

    public function login()
    {
        if (session()->get('user_id')) {
            return redirect()->to('/dashboard');
        }
        return view('auth/login', ['title' => 'Masuk']);
    }

    public function attempt()
    {
        $rules = [
            'username' => 'required|max_length[50]',
            'password' => 'required',
        ];

        if (!$this->validate($rules)) {
            return view('auth/login', [
                'title'    => 'Masuk',
                'errors'   => $this->validator->getErrors(),
                'old'      => $this->request->getPost(),
            ]);
        }

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $this->userModel->where('username', $username)->where('status', 'active')->first();

        if (!$user || !password_verify($password, $user->password)) {
            $this->audit->log('login_gagal', "Login gagal untuk username: {$username}");
            return view('auth/login', [
                'title'  => 'Masuk',
                'errors' => ['username' => 'Username atau password salah.'],
                'old'    => ['username' => $username],
            ]);
        }

        // Regenerate session
        session()->regenerate(true);

        // Fetch roles & permissions from DB
        $db = db_connect();

        $roles = $db->table('user_roles')
            ->select('roles.name, roles.label')
            ->join('roles', 'roles.id = user_roles.role_id')
            ->where('user_roles.user_id', $user->id)
            ->get()->getResult();

        $perms = $db->table('role_permissions')
            ->select('permissions.name')
            ->join('permissions', 'permissions.id = role_permissions.permission_id')
            ->join('user_roles', 'user_roles.role_id = role_permissions.role_id')
            ->where('user_roles.user_id', $user->id)
            ->get()->getResult();

        $roleNames = array_column($roles, 'name');
        $permNames = array_column($perms, 'name');

        session()->set([
            'user_id'    => $user->id,
            'user_uuid'  => $user->uuid,
            'username'   => $user->username,
            'name'       => $user->name,
            'email'      => $user->email,
            'roles'      => $roleNames,
            'role_labels'=> array_column($roles, 'label'),
            'permissions'=> $permNames,
            'logged_in'  => true,
        ]);

        // Update last login
        $this->userModel->update($user->id, ['last_login_at' => date('Y-m-d H:i:s')]);

        $this->audit->log('login', "Berhasil login: {$username}");

        // Redirect based on role
        if (in_array('admin', $roleNames)) {
            return redirect()->to('/dashboard');
        }
        return redirect()->to('/dashboard');
    }

    public function logout()
    {
        $this->audit->log('logout', 'Pengguna logout');
        session()->destroy();
        return redirect()->to('/login')->with('message', 'Anda telah keluar dari sistem.');
    }
}
