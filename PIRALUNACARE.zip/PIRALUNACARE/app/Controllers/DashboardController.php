<?php

namespace App\Controllers;

use App\Models\SasaranModel;
use App\Models\KegiatanModel;
use App\Models\KunjunganModel;
use App\Models\PengukuranModel;

class DashboardController extends BaseController
{
    public function index()
    {
        $roles = session()->get('roles') ?? [];
        $userRole = $roles[0] ?? 'kader';

        $sasaranModel  = new SasaranModel();
        $kegiatanModel = new KegiatanModel();
        $kunjunganModel = new KunjunganModel();
        $pengukuranModel = new PengukuranModel();
        $db = db_connect();

        $common = [
            'title'      => 'Dashboard',
            'userRole'   => $userRole,
            'userRoleLabel'=> $this->getRoleLabel($userRole),
            'totalSasaran'  => $sasaranModel->where('status', 'aktif')->countAllResults(),
            'totalKegiatan' => $kegiatanModel->countAllResults(),
            'totalKunjungan'=> $kunjunganModel->countAllResults(),
            'kegiatanHari'  => $kegiatanModel->where('tanggal', date('Y-m-d'))->findAll(),
            'sasaranTerbaru'=> $sasaranModel->where('status', 'aktif')->orderBy('created_at', 'DESC')->limit(5)->findAll(),
        ];

        if (in_array('admin', $roles)) {
            return view('dashboard/admin', array_merge($common, [
                'totalPengguna'  => $db->table('users')->countAllResults(),
                'totalAudit'     => $db->table('audit_logs')->countAllResults(),
                'recentAudit'    => $db->table('audit_logs')->orderBy('created_at', 'DESC')->limit(10)->get()->getResult(),
            ]));
        }

        if (in_array('koordinator', $roles)) {
            $kegiatanStatus = [];
            foreach (['direncanakan', 'berlangsung', 'selesai', 'dibatalkan'] as $status) {
                $kegiatanStatus[$status] = $db->table('kegiatan_posyandu')->where('status', $status)->countAllResults();
            }
            return view('dashboard/koordinator', array_merge($common, [
                'kegiatanStatus' => $kegiatanStatus,
                'rekapKelompok'  => $sasaranModel->select('kelompok, COUNT(*) as jumlah')->where('status', 'aktif')->groupBy('kelompok')->get()->getResult(),
            ]));
        }

        if (in_array('tenaga_kesehatan', $roles)) {
            $pengukuranTerbaru = $db->table('pengukuran')
                ->select('pengukuran.*, sasaran.nama')
                ->join('sasaran', 'sasaran.id = pengukuran.sasaran_id')
                ->orderBy('pengukuran.tanggal', 'DESC')
                ->limit(10)
                ->get()->getResult();

            return view('dashboard/tenaga_kesehatan', array_merge($common, [
                'pengukuranTerbaru'=> $pengukuranTerbaru,
                'sasaranButuhValidasi'=> $db->table('catatan_pelayanan')->where('status', 'belum_lengkap')->countAllResults(),
            ]));
        }

        if (in_array('petugas_ukur', $roles)) {
            return view('dashboard/petugas_ukur', array_merge($common, [
                'sasaranButuhPengukuran'=> $sasaranModel->where('status', 'aktif')->countAllResults(),
            ]));
        }

        // Default: kader
        return view('dashboard/kader', $common);
    }

    private function getRoleLabel(string $role): string
    {
        $labels = [
            'admin'          => 'Administrator',
            'kader'          => 'Kader Posyandu',
            'petugas_ukur'   => 'Petugas Pengukuran',
            'tenaga_kesehatan'=> 'Tenaga Kesehatan',
            'koordinator'     => 'Koordinator Posyandu',
        ];
        return $labels[$role] ?? 'Pengguna';
    }
}
