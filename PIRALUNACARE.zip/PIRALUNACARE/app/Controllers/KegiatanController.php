<?php

namespace App\Controllers;

use App\Models\KegiatanModel;
use App\Models\KunjunganModel;
use App\Models\SasaranModel;
use App\Models\AuditLogModel;

class KegiatanController extends BaseController
{
    protected $kegiatan;
    protected $audit;

    public function __construct()
    {
        $this->kegiatan = new KegiatanModel();
        $this->audit    = new AuditLogModel();
    }

    public function index()
    {
        $status = $this->request->getGet('status');
        $tanggal = $this->request->getGet('tanggal');

        $this->kegiatan->select('kegiatan_posyandu.*, posyandu.nama as posyandu_nama')
            ->join('posyandu', 'posyandu.id = kegiatan_posyandu.posyandu_id');

        if ($status) $this->kegiatan->where('kegiatan_posyandu.status', $status);
        if ($tanggal) $this->kegiatan->where('kegiatan_posyandu.tanggal', $tanggal);

        return view('kegiatan/index', [
            'title'    => 'Kegiatan Posyandu',
            'kegiatan' => $this->kegiatan->orderBy('tanggal', 'DESC')->paginate(15),
            'pager'    => $this->kegiatan->pager,
            'status'   => $status,
            'tanggal'  => $tanggal,
        ]);
    }

    public function create()
    {
        $db = db_connect();
        return view('kegiatan/create', [
            'title'     => 'Buat Kegiatan',
            'posyandu'  => $db->table('posyandu')->where('status', 'aktif')->get()->getResult(),
            'petugas'   => $db->table('users')->where('status', 'active')->get()->getResult(),
        ]);
    }

    public function store()
    {
        $rules = [
            'posyandu_id'        => 'required|integer',
            'tanggal'            => 'required|valid_date',
            'waktu_mulai'        => 'permit_empty',
            'waktu_selesai'      => 'permit_empty',
            'lokasi'             => 'permit_empty|max_length[200]',
            'jenis_kegiatan'     => 'required|in_list[imunisasi,pesan_berat_badan,konsultasi_kia,vitamin_a,tablet_tambah_darah,edukasi_gizi,lainnya]',
            'jenis_kegiatan_lain'=> 'permit_empty|max_length[100]',
            'status'             => 'required|in_list[direncanakan,berlangsung,selesai,dibatalkan]',
        ];

        if (!$this->validate($rules)) {
            $db = db_connect();
            return view('kegiatan/create', [
                'title'    => 'Buat Kegiatan',
                'errors'   => $this->validator->getErrors(),
                'old'      => $this->request->getPost(),
                'posyandu' => $db->table('posyandu')->where('status', 'aktif')->get()->getResult(),
                'petugas'  => $db->table('users')->where('status', 'active')->get()->getResult(),
            ]);
        }

        $postData = $this->request->getPost();

        // Handle jenis kegiatan custom input
        if (!empty($postData['jenis_kegiatan']) && $postData['jenis_kegiatan'] === 'lainnya') {
            $postData['jenis_kegiatan_lain'] = $postData['jenis_kegiatan_lain'] ?? null;
        } else {
            $postData['jenis_kegiatan_lain'] = null;
        }

        // Handle empty petugas_id -> NULL
        if (empty($postData['petugas_id'])) {
            $postData['petugas_id'] = null;
        }

        $id = $this->kegiatan->insert($postData);
        $this->audit->log('buat_kegiatan', "Membuat kegiatan tanggal " . $this->request->getPost('tanggal'), 'kegiatan_posyandu', $id);

        return redirect()->to('/kegiatan/' . $id)->with('success', 'Kegiatan berhasil dibuat.');
    }

    public function show($id)
    {
        $kegiatan = $this->kegiatan->select('kegiatan_posyandu.*, posyandu.nama as posyandu_nama')
            ->join('posyandu', 'posyandu.id = kegiatan_posyandu.posyandu_id')
            ->find($id);

        if (!$kegiatan) return redirect()->back()->with('error', 'Kegiatan tidak ditemukan.');

        $db = db_connect();

        // Kunjungan + sasaran info
        $kunjungan = $db->table('kunjungan')
            ->select('kunjungan.*, sasaran.nama as sasaran_nama, sasaran.kode_sasaran, sasaran.kelompok')
            ->join('sasaran', 'sasaran.id = kunjungan.sasaran_id')
            ->where('kunjungan.kegiatan_id', $id)
            ->orderBy('kunjungan.created_at', 'ASC')
            ->get()->getResult();

        // Antrean
        $antrean = $db->table('antrean')
            ->select('antrean.*, kunjungan.kode_kunjungan, sasaran.nama as sasaran_nama, sasaran.kode_sasaran')
            ->join('kunjungan', 'kunjungan.id = antrean.kunjungan_id')
            ->join('sasaran', 'sasaran.id = kunjungan.sasaran_id')
            ->where('antrean.kegiatan_id', $id)
            ->orderBy('antrean.nomor', 'ASC')
            ->get()->getResult();

        // Stats
        $totalDaftar = count($kunjungan);
        $totalHadir  = count(array_filter($kunjungan, fn($k) => in_array($k->status, ['hadir', 'selesai'])));
        $dalamAntrean = count(array_filter($antrean, fn($a) => in_array($a->status, ['menunggu', 'sedang_dilayani'])));

        return view('kegiatan/show', [
            'title'      => 'Detail Kegiatan',
            'kegiatan'   => $kegiatan,
            'kunjungan'  => $kunjungan,
            'antrean'    => $antrean,
            'totalDaftar'=> $totalDaftar,
            'totalHadir' => $totalHadir,
            'dalamAntrean'=> $dalamAntrean,
        ]);
    }

    public function edit($id)
    {
        $kegiatan = $this->kegiatan->find($id);
        if (!$kegiatan) return redirect()->back()->with('error', 'Kegiatan tidak ditemukan.');

        $db = db_connect();
        return view('kegiatan/edit', [
            'title'    => 'Edit Kegiatan',
            'kegiatan' => $kegiatan,
            'posyandu' => $db->table('posyandu')->where('status', 'aktif')->get()->getResult(),
            'petugas'  => $db->table('users')->where('status', 'active')->get()->getResult(),
        ]);
    }

    public function update($id)
    {
        $kegiatan = $this->kegiatan->find($id);
        if (!$kegiatan) return redirect()->back()->with('error', 'Kegiatan tidak ditemukan.');

        $rules = [
            'posyandu_id'        => 'required|integer',
            'tanggal'            => 'required|valid_date',
            'waktu_mulai'        => 'permit_empty',
            'waktu_selesai'      => 'permit_empty',
            'lokasi'             => 'permit_empty|max_length[200]',
            'jenis_kegiatan'     => 'required|in_list[imunisasi,pesan_berat_badan,konsultasi_kia,vitamin_a,tablet_tambah_darah,edukasi_gizi,lainnya]',
            'jenis_kegiatan_lain'=> 'permit_empty|max_length[100]',
            'status'             => 'required|in_list[direncanakan,berlangsung,selesai,dibatalkan]',
        ];

        if (!$this->validate($rules)) {
            $db = db_connect();
            return view('kegiatan/edit', [
                'title'    => 'Edit Kegiatan',
                'errors'   => $this->validator->getErrors(),
                'old'      => $this->request->getPost(),
                'kegiatan' => $kegiatan,
                'posyandu' => $db->table('posyandu')->where('status', 'aktif')->get()->getResult(),
                'petugas'  => $db->table('users')->where('status', 'active')->get()->getResult(),
            ]);
        }

        $postData = $this->request->getPost();

        // Handle jenis kegiatan custom input
        if (!empty($postData['jenis_kegiatan']) && $postData['jenis_kegiatan'] === 'lainnya') {
            $postData['jenis_kegiatan_lain'] = $postData['jenis_kegiatan_lain'] ?? null;
        } else {
            $postData['jenis_kegiatan_lain'] = null;
        }

        // Handle empty petugas_id -> NULL
        if (empty($postData['petugas_id'])) {
            $postData['petugas_id'] = null;
        }

        $this->kegiatan->update($id, $postData);
        $this->audit->log('ubah_kegiatan', "Mengubah kegiatan ID {$id}", 'kegiatan_posyandu', $id);

        return redirect()->to('/kegiatan/' . $id)->with('success', 'Kegiatan berhasil diperbarui.');
    }

    public function changeStatus($id, $status)
    {
        $allowed = ['direncanakan', 'berlangsung', 'selesai', 'dibatalkan'];
        if (!in_array($status, $allowed)) {
            return redirect()->back()->with('error', 'Status tidak valid.');
        }

        $kegiatan = $this->kegiatan->find($id);
        if (!$kegiatan) return redirect()->back()->with('error', 'Kegiatan tidak ditemukan.');

        $this->kegiatan->update($id, ['status' => $status]);
        $this->audit->log('ubah_status_kegiatan', "Status kegiatan {$id} → {$status}", 'kegiatan_posyandu', $id);

        return redirect()->back()->with('success', "Status diubah menjadi: {$status}");
    }
}
