<?php

namespace App\Controllers;

use App\Models\SasaranModel;
use App\Models\AuditLogModel;

class SasaranController extends BaseController
{
    protected $sasaran;
    protected $audit;

    public function __construct()
    {
        $this->sasaran = new SasaranModel();
        $this->audit   = new AuditLogModel();
    }

    public function index()
    {
        $q       = $this->request->getGet('q');
        $kelompok = $this->request->getGet('kelompok');

        // Apply conditions via model
        $this->sasaran->where('deleted_at', null);

        if ($q) {
            $this->sasaran->groupStart()
                ->like('nama', $q)
                ->orLike('kode_sasaran', $q)
                ->orLike('nik', $q)
                ->groupEnd();
        }
        if ($kelompok) {
            $this->sasaran->where('kelompok', $kelompok);
        }

        $data = [
            'title'   => 'Data Sasaran',
            'sasaran' => $this->sasaran->orderBy('nama', 'ASC')->paginate(15, 'default'),
            'pager'   => $this->sasaran->pager,
            'q'       => $q,
            'kelompok'=> $kelompok,
        ];

        return view('sasaran/index', $data);
    }

    public function create()
    {
        $lastKode = $this->sasaran->selectMax('kode_sasaran')->where('deleted_at', null)->first();
        $nextNum  = 1;
        if ($lastKode && $lastKode->kode_sasaran) {
            $num = (int) preg_replace('/\D/', '', substr($lastKode->kode_sasaran, 3));
            $nextNum = $num + 1;
        }

        return view('sasaran/create', [
            'title' => 'Tambah Sasaran',
            'nextKode' => 'SAS-' . str_pad($nextNum, 5, '0', STR_PAD_LEFT),
        ]);
    }

    public function store()
    {
        $rules = [
            'kode_sasaran'  => 'required|max_length[30]|is_unique[sasaran.kode_sasaran,id,{id}]',
            'posyandu_id'   => 'required|integer',
            'nama'          => 'required|max_length[200]',
            'jenis_kelamin' => 'required|in_list[L,P]',
            'kelompok'      => 'required',
            'tanggal_lahir' => 'permit_empty|valid_date',
            'nik'           => 'permit_empty|max_length[20]',
        ];

        if (!$this->validate($rules)) {
            return view('sasaran/create', [
                'title'     => 'Tambah Sasaran',
                'errors'    => $this->validator->getErrors(),
                'old'       => $this->request->getPost(),
                'nextKode'  => $this->request->getPost('kode_sasaran'),
            ]);
        }

        $postData = $this->request->getPost();
        $postData['created_by'] = session()->get('user_id');
        $postData['status']     = 'aktif';

        // Handle kelompok custom input
        if (!empty($postData['kelompok']) && $postData['kelompok'] === 'lainnya') {
            $postData['kelompok_lain'] = $postData['kelompok_lain'] ?? null;
        } else {
            $postData['kelompok_lain'] = null;
        }

        // Default posyandu if not set
        if (empty($postData['posyandu_id'])) {
            $posyandu = db_connect()->table('posyandu')->where('status', 'aktif')->orderBy('id', 'ASC')->get()->getRow();
            $postData['posyandu_id'] = $posyandu->id ?? 0;
        }

        // Verify posyandu exists
        $exists = db_connect()->table('posyandu')->where('id', $postData['posyandu_id'])->countAllResults();
        if (!$exists) {
            return view('sasaran/create', [
                'title'    => 'Tambah Sasaran',
                'errors'   => ['posyandu_id' => 'Posyandu tidak ditemukan. Hubungi administrator.'],
                'old'      => $this->request->getPost(),
                'nextKode' => $this->request->getPost('kode_sasaran'),
            ]);
        }

        $id = $this->sasaran->insert($postData);

        $this->audit->log('tambah_sasaran', "Menambahkan sasaran: {$postData['nama']} ({$postData['kode_sasaran']})", 'sasaran', $id);

        return redirect()->to('/sasaran/' . $id)->with('success', 'Data sasaran berhasil disimpan.');
    }

    public function show($id)
    {
        $sasaran = $this->sasaran->find($id);
        if (!$sasaran) {
            return redirect()->back()->with('error', 'Sasaran tidak ditemukan.');
        }

        $db = db_connect();

        $kunjungan = $db->table('kunjungan')
            ->where('sasaran_id', $id)
            ->orderBy('tanggal', 'DESC')
            ->get()->getResult();

        $pengukuran = $db->table('pengukuran')
            ->where('sasaran_id', $id)
            ->orderBy('tanggal', 'DESC')
            ->get()->getResult();

        $wali = $db->table('wali_pengasuh')
            ->where('sasaran_id', $id)
            ->get()->getResult();

        return view('sasaran/detail', [
            'title'     => 'Detail Sasaran',
            'sasaran'   => $sasaran,
            'kunjungan' => $kunjungan,
            'pengukuran'=> $pengukuran,
            'wali'      => $wali,
        ]);
    }

    public function edit($id)
    {
        $sasaran = $this->sasaran->find($id);
        if (!$sasaran) {
            return redirect()->back()->with('error', 'Sasaran tidak ditemukan.');
        }

        return view('sasaran/edit', [
            'title'   => 'Edit Sasaran',
            'sasaran' => $sasaran,
        ]);
    }

    public function update($id)
    {
        $sasaran = $this->sasaran->find($id);
        if (!$sasaran) {
            return redirect()->back()->with('error', 'Sasaran tidak ditemukan.');
        }

        $rules = [
            'nama'          => 'required|max_length[200]',
            'jenis_kelamin' => 'required|in_list[L,P]',
            'kelompok'      => 'required',
        ];

        if (!$this->validate($rules)) {
            return view('sasaran/edit', [
                'title'   => 'Edit Sasaran',
                'errors'  => $this->validator->getErrors(),
                'old'     => $this->request->getPost(),
                'sasaran' => $sasaran,
            ]);
        }

        $postData = $this->request->getPost();

        // Handle kelompok custom input
        if (!empty($postData['kelompok']) && $postData['kelompok'] === 'lainnya') {
            $postData['kelompok_lain'] = $postData['kelompok_lain'] ?? null;
        } else {
            $postData['kelompok_lain'] = null;
        }

        $this->sasaran->update($id, $postData);
        $this->audit->log('ubah_sasaran', "Mengubah data sasaran ID: {$id}", 'sasaran', $id);

        return redirect()->to('/sasaran/' . $id)->with('success', 'Data sasaran berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $sasaran = $this->sasaran->find($id);
        if (!$sasaran) {
            return redirect()->back()->with('error', 'Sasaran tidak ditemukan.');
        }

        $this->sasaran->delete($id);
        $this->audit->log('nonaktif_sasaran', "Menonaktifkan sasaran: {$sasaran->nama}", 'sasaran', $id);

        return redirect()->to('/sasaran')->with('success', 'Data sasaran berhasil dinonaktifkan.');
    }

    public function checkDuplicate()
    {
        $nama    = $this->request->getGet('nama');
        $tanggal = $this->request->getGet('tanggal_lahir');

        if (!$nama && !$tanggal) {
            return $this->response->setJSON(['duplicate' => false]);
        }

        $builder = $this->sasaran->builder()->where('deleted_at', null);
        $builder->groupStart();
        if ($nama)    $builder->like('nama', $nama);
        if ($tanggal) $builder->orWhere('tanggal_lahir', $tanggal);
        $builder->groupEnd();

        $results = $builder->limit(5)->get()->getResult();

        return $this->response->setJSON([
            'duplicate' => count($results) > 0,
            'data'      => $results,
        ]);
    }
}
