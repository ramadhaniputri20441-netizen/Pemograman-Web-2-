<?php

namespace App\Controllers;

use App\Models\PengukuranModel;
use App\Models\AuditLogModel;

class PengukuranController extends BaseController
{
    protected $pengukuran;
    protected $audit;

    public function __construct()
    {
        $this->pengukuran = new PengukuranModel();
        $this->audit      = new AuditLogModel();
    }

    /**
     * Form input pengukuran untuk sasaran tertentu
     */
    public function create()
    {
        $sasaranId = $this->request->getGet('sasaran_id');
        $kunjunganId = $this->request->getGet('kunjungan_id');

        if (!$sasaranId) return redirect()->back()->with('error', 'Sasaran tidak dipilih.');

        $db = db_connect();
        $sasaran = $db->table('sasaran')->where('id', $sasaranId)->get()->getRow();
        if (!$sasaran) return redirect()->back()->with('error', 'Sasaran tidak ditemukan.');

        // Daftar kunjungan sasaran ini
        $kunjunganList = $db->table('kunjungan')
            ->where('sasaran_id', $sasaranId)
            ->orderBy('tanggal', 'DESC')
            ->get()->getResult();

        // Riwayat pengukuran
        $riwayat = $db->table('pengukuran')
            ->where('sasaran_id', $sasaranId)
            ->orderBy('tanggal', 'DESC')
            ->limit(20)
            ->get()->getResult();

        // Usia untuk menentukan form relevan
        $usiaBulan = 0;
        if ($sasaran->tanggal_lahir) {
            $d = date_diff(date_create($sasaran->tanggal_lahir), date_create('today'));
            $usiaBulan = $d->y * 12 + $d->m;
        }

        return view('pengukuran/create', [
            'title'       => 'Input Pengukuran',
            'sasaran'     => $sasaran,
            'kunjunganList'=> $kunjunganList,
            'kunjunganId' => $kunjunganId,
            'riwayat'     => $riwayat,
            'usiaBulan'   => $usiaBulan,
        ]);
    }

    public function store()
    {
        $sasaranId   = $this->request->getPost('sasaran_id');
        $kunjunganId = $this->request->getPost('kunjungan_id');

        $rules = [
            'sasaran_id'   => 'required|integer',
            'kunjungan_id' => 'required|integer',
            'jenis'        => 'required',
            'nilai'        => 'required|decimal',
            'satuan'       => 'required',
            'tanggal'      => 'required',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->with('error', implode(' ', $this->validator->getErrors()));
        }

        // Validate reasonable range
        $jenis  = $this->request->getPost('jenis');
        $nilai  = (float) $this->request->getPost('nilai');
        $ranges = [
            'berat_badan'    => [0.5, 200, 'kg'],
            'tinggi_badan'   => [30, 250, 'cm'],
            'panjang_badan'  => [30, 120, 'cm'],
            'lingkar_lengan' => [5, 60, 'cm'],
            'lingkar_kepala' => [20, 70, 'cm'],
            'lingkar_pinggang'=> [20, 200, 'cm'],
            'imt'            => [5, 100, 'kg/m²'],
            'tekanan_darah'  => [40, 300, 'mmHg'],
        ];

        if (isset($ranges[$jenis])) {
            [$min, $max, $unit] = $ranges[$jenis];
            if ($nilai < $min || $nilai > $max) {
                return redirect()->back()->with('error', "Nilai {$nilai} di luar rentang wajar ({$min}–{$max} {$unit}). Periksa kembali input Anda.");
            }
        }

        $id = $this->pengukuran->insert([
            'sasaran_id'   => $sasaranId,
            'kunjungan_id' => $kunjunganId,
            'jenis'        => $jenis,
            'nilai'        => $nilai,
            'satuan'       => $this->request->getPost('satuan'),
            'tanggal'      => $this->request->getPost('tanggal') . ' ' . date('H:i:s'),
            'petugas_id'   => session()->get('user_id'),
            'catatan'      => $this->request->getPost('catatan'),
            'status'       => 'lengkap',
        ]);

        $this->audit->log('input_pengukuran', "Input {$jenis}: {$nilai} {$this->request->getPost('satuan')} untuk sasaran #{$sasaranId}", 'pengukuran', $id);

        return redirect()->to('/pengukuran/create?sasaran_id=' . $sasaranId)->with('success', "Pengukuran {$jenis} tersimpan.");
    }

    /**
     * Tandai diverifikasi (oleh tenaga kesehatan)
     */
    public function verifikasi($id)
    {
        $p = $this->pengukuran->find($id);
        if (!$p) return redirect()->back()->with('error', 'Data tidak ditemukan.');

        $this->pengukuran->update($id, ['status' => 'diverifikasi']);
        $this->audit->log('verifikasi_pengukuran', "Memverifikasi pengukuran ID {$id}", 'pengukuran', $id);

        return redirect()->back()->with('success', 'Pengukuran diverifikasi.');
    }
}
