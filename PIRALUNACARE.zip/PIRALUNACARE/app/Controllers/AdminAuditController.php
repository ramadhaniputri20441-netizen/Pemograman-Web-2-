<?php

namespace App\Controllers;

class AdminAuditController extends BaseController
{
    public function index()
    {
        $db = db_connect();
        $q        = $this->request->getGet('q');
        $aksi     = $this->request->getGet('aksi');
        $tanggal  = $this->request->getGet('tanggal');

        $builder = $db->table('audit_logs')->orderBy('id', 'DESC');

        if ($q) {
            $builder->groupStart()
                ->like('username', $q)
                ->orLike('keterangan', $q)
                ->orLike('aksi', $q)
                ->groupEnd();
        }
        if ($aksi) $builder->where('aksi', $aksi);
        if ($tanggal) $builder->where('DATE(created_at)', $tanggal);

        // Get distinct aksi for filter
        $aksiList = $db->table('audit_logs')->select('aksi')->distinct()->orderBy('aksi')->get()->getResult();

        // Paginate via builder
        $perPage = 30;
        $total = (clone $builder)->countAllResults(false);
        $page = max(1, (int) $this->request->getGet('page'));
        $offset = ($page - 1) * $perPage;
        $logs = $builder->limit($perPage, $offset)->get()->getResult();

        return view('admin/audit/index', [
            'title'   => 'Audit Log',
            'logs'    => $logs,
            'total'   => $total,
            'page'    => $page,
            'perPage' => $perPage,
            'q'       => $q,
            'aksi'    => $aksi,
            'tanggal' => $tanggal,
            'aksiList'=> $aksiList,
        ]);
    }

    public function export()
    {
        $db = db_connect();
        $rows = $db->table('audit_logs')
            ->orderBy('id', 'DESC')
            ->limit(10000)
            ->get()->getResult();

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=audit_log_' . date('Y-m-d') . '.csv');

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($output, ['Waktu', 'Username', 'Aksi', 'Keterangan', 'Tabel', 'Record ID', 'IP Address']);

        foreach ($rows as $r) {
            fputcsv($output, [
                $r->created_at, $r->username, $r->aksi, $r->keterangan,
                $r->tabel, $r->record_id, $r->ip_address,
            ]);
        }
        fclose($output);
        exit;
    }
}
