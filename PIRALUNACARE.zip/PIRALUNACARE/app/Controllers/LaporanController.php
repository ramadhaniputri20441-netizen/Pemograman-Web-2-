<?php

namespace App\Controllers;

use App\Models\AuditLogModel;

class LaporanController extends BaseController
{
    public function index()
    {
        $db = db_connect();

        $tanggalMulai = $this->request->getGet('mulai') ?: date('Y-m-01');
        $tanggalAkhir  = $this->request->getGet('akhir') ?: date('Y-m-d');
        $posyanduId   = $this->request->getGet('posyandu_id');
        $kelompok     = $this->request->getGet('kelompok');

        // Base conditions
        $kunjunganQ = $db->table('kunjungan')
            ->where('kunjungan.tanggal >=', $tanggalMulai)
            ->where('kunjungan.tanggal <=', $tanggalAkhir);

        if ($posyanduId) {
            $kunjunganQ->join('kegiatan_posyandu', 'kegiatan_posyandu.id = kunjungan.kegiatan_id')
                ->where('kegiatan_posyandu.posyandu_id', $posyanduId);
        }

        $sasaranQ = $db->table('sasaran')->where('sasaran.status', 'aktif');
        if ($kelompok) $sasaranQ->where('sasaran.kelompok', $kelompok);

        $data = [
            'title'       => 'Laporan & Rekap',
            'tanggalMulai'=> $tanggalMulai,
            'tanggalAkhir' => $tanggalAkhir,
            'posyanduId'  => $posyanduId,
            'kelompok'    => $kelompok,
            'posyanduList'=> $db->table('posyandu')->get()->getResult(),

            // Stats
            'totalSasaranAktif' => $sasaranQ->countAllResults(),
            'totalKunjungan'    => (clone $kunjunganQ)->countAllResults(),
            'totalHadir'        => (clone $kunjunganQ)->where('kunjungan.status', 'hadir')->countAllResults() + (clone $kunjunganQ)->where('kunjungan.status', 'selesai')->countAllResults(),

            // Per kelompok
            'rekapKelompok' => $db->table('sasaran')
                ->select('kelompok, COUNT(*) as jumlah')
                ->where('status', 'aktif')
                ->groupBy('kelompok')
                ->get()->getResult(),

            // Kunjungan per hari
            'kunjunganPerHari' => $db->table('kunjungan')
                ->select('tanggal, COUNT(*) as jumlah')
                ->where('tanggal >=', $tanggalMulai)
                ->where('tanggal <=', $tanggalAkhir)
                ->groupBy('tanggal')
                ->orderBy('tanggal', 'ASC')
                ->get()->getResult(),

            // Pengukuran per jenis
            'rekapPengukuran' => $db->table('pengukuran')
                ->select('jenis, COUNT(*) as jumlah, AVG(nilai) as rata')
                ->where('tanggal >=', $tanggalMulai . ' 00:00:00')
                ->where('tanggal <=', $tanggalAkhir . ' 23:59:59')
                ->groupBy('jenis')
                ->get()->getResult(),

            // Lengkap vs belum
            'catatanLengkap' => $db->table('catatan_pelayanan')
                ->where('status', 'lengkap')
                ->where('created_at >=', $tanggalMulai)
                ->where('created_at <=', $tanggalAkhir . ' 23:59:59')
                ->countAllResults(),

            // Kegiatan
            'totalKegiatan' => $db->table('kegiatan_posyandu')
                ->where('tanggal >=', $tanggalMulai)
                ->where('tanggal <=', $tanggalAkhir)
                ->countAllResults(),
        ];

        return view('laporan/index', $data);
    }

    /**
     * Ekspor data kunjungan ke CSV
     */
    public function exportKunjungan()
    {
        $mulai = $this->request->getGet('mulai') ?: date('Y-m-01');
        $akhir = $this->request->getGet('akhir') ?: date('Y-m-d');

        $db = db_connect();
        $rows = $db->table('kunjungan')
            ->select('kunjungan.kode_kunjungan, kunjungan.tanggal, kunjungan.status, sasaran.kode_sasaran, sasaran.nama, sasaran.kelompok, sasaran.jenis_kelamin, sasaran.tanggal_lahir')
            ->join('sasaran', 'sasaran.id = kunjungan.sasaran_id')
            ->where('kunjungan.tanggal >=', $mulai)
            ->where('kunjungan.tanggal <=', $akhir)
            ->orderBy('kunjungan.tanggal', 'ASC')
            ->get()->getResult();

        // Audit log
        $audit = new AuditLogModel();
        $audit->log('ekspor_laporan', "Ekspor CSV kunjungan {$mulai} s/d {$akhir} (" . count($rows) . " baris)");

        // Output CSV
        header('Content-Type: text/csv; charset=utf-8');
        header("Content-Disposition: attachment; filename=kunjungan_{$mulai}_{$akhir}.csv");

        $output = fopen('php://output', 'w');
        // BOM for Excel
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($output, ['Kode Kunjungan', 'Tanggal', 'Status', 'Kode Sasaran', 'Nama', 'Kelompok', 'JK', 'Tgl Lahir']);

        foreach ($rows as $r) {
            fputcsv($output, [
                $r->kode_kunjungan, $r->tanggal, $r->status,
                $r->kode_sasaran, $r->nama, $r->kelompok,
                $r->jenis_kelamin, $r->tanggal_lahir,
            ]);
        }
        fclose($output);
        exit;
    }

    /**
     * Ekspor data pengukuran ke CSV
     */
    public function exportPengukuran()
    {
        $mulai = $this->request->getGet('mulai') ?: date('Y-m-01');
        $akhir = $this->request->getGet('akhir') ?: date('Y-m-d');

        $db = db_connect();
        $rows = $db->table('pengukuran')
            ->select('pengukuran.tanggal, pengukuran.jenis, pengukuran.nilai, pengukuran.satuan, pengukuran.status, sasaran.kode_sasaran, sasaran.nama, sasaran.kelompok')
            ->join('sasaran', 'sasaran.id = pengukuran.sasaran_id')
            ->where('pengukuran.tanggal >=', $mulai . ' 00:00:00')
            ->where('pengukuran.tanggal <=', $akhir . ' 23:59:59')
            ->orderBy('pengukuran.tanggal', 'ASC')
            ->get()->getResult();

        $audit = new AuditLogModel();
        $audit->log('ekspor_laporan', "Ekspor CSV pengukuran {$mulai} s/d {$akhir} (" . count($rows) . " baris)");

        header('Content-Type: text/csv; charset=utf-8');
        header("Content-Disposition: attachment; filename=pengukuran_{$mulai}_{$akhir}.csv");

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($output, ['Tanggal', 'Jenis', 'Nilai', 'Satuan', 'Status', 'Kode Sasaran', 'Nama', 'Kelompok']);

        foreach ($rows as $r) {
            fputcsv($output, [
                $r->tanggal, $r->jenis, $r->nilai, $r->satuan,
                $r->status, $r->kode_sasaran, $r->nama, $r->kelompok,
            ]);
        }
        fclose($output);
        exit;
    }
}
