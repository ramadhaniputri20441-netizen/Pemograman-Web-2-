<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\AuditLogModel;

class AdminPenggunaController extends BaseController
{
    protected $user;
    protected $audit;

    public function __construct()
    {
        $this->user  = new UserModel();
        $this->audit = new AuditLogModel();
    }

    public function index()
    {
        $q = $this->request->getGet('q');
        $this->user->select('users.*, GROUP_CONCAT(roles.label SEPARATOR ", ") as role_labels')
            ->join('user_roles', 'user_roles.user_id = users.id', 'left')
            ->join('roles', 'roles.id = user_roles.role_id', 'left')
            ->groupBy('users.id');

        if ($q) {
            $this->user->groupStart()->like('name', $q)->orLike('username', $q)->orLike('email', $q)->groupEnd();
        }

        return view('admin/pengguna/index', [
            'title' => 'Manajemen Pengguna',
            'users' => $this->user->orderBy('name', 'ASC')->paginate(15),
            'pager' => $this->user->pager,
            'q'     => $q,
        ]);
    }

    public function create()
    {
        $db = db_connect();
        return view('admin/pengguna/create', [
            'title' => 'Tambah Pengguna',
            'roles' => $db->table('roles')->get()->getResult(),
        ]);
    }

    public function store()
    {
        $rules = [
            'name'     => 'required|max_length[150]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'username' => 'required|max_length[50]|is_unique[users.username]',
            'password' => 'required|min_length[6]',
            'role_id'  => 'required|integer',
        ];

        $db = db_connect();
        if (!$this->validate($rules)) {
            return view('admin/pengguna/create', [
                'title' => 'Tambah Pengguna',
                'errors'=> $this->validator->getErrors(),
                'old'   => $this->request->getPost(),
                'roles' => $db->table('roles')->get()->getResult(),
            ]);
        }

        $postData = $this->request->getPost();
        $userId = $this->user->insert([
            'uuid'     => sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0x0fff)|0x4000, mt_rand(0,0x3fff)|0x8000, mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff)),
            'name'     => $postData['name'],
            'email'    => $postData['email'],
            'username' => $postData['username'],
            'password' => password_hash($postData['password'], PASSWORD_DEFAULT),
            'phone'    => $postData['phone'] ?? null,
            'status'   => $postData['status'] ?? 'active',
        ]);

        $db->table('user_roles')->insert(['user_id' => $userId, 'role_id' => $postData['role_id']]);
        $this->audit->log('tambah_pengguna', "Menambahkan pengguna: {$postData['username']}", 'users', $userId);

        return redirect()->to('/admin/pengguna')->with('success', 'Pengguna berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $user = $this->user->find($id);
        if (!$user) return redirect()->back()->with('error', 'Pengguna tidak ditemukan.');

        $db = db_connect();
        $userRole = $db->table('user_roles')->where('user_id', $id)->get()->getRow();

        return view('admin/pengguna/edit', [
            'title'    => 'Edit Pengguna',
            'user'     => $user,
            'roles'    => $db->table('roles')->get()->getResult(),
            'userRole' => $userRole,
        ]);
    }

    public function update($id)
    {
        $user = $this->user->find($id);
        if (!$user) return redirect()->back()->with('error', 'Pengguna tidak ditemukan.');

        $rules = [
            'name'  => 'required|max_length[150]',
            'email' => "required|valid_email|is_unique[users.email,id,{$id}]",
            'role_id'=> 'required|integer',
        ];

        if (!empty($this->request->getPost('password'))) {
            $rules['password'] = 'min_length[6]';
        }

        $db = db_connect();
        if (!$this->validate($rules)) {
            $userRole = $db->table('user_roles')->where('user_id', $id)->get()->getRow();
            return view('admin/pengguna/edit', [
                'title'    => 'Edit Pengguna',
                'errors'   => $this->validator->getErrors(),
                'old'      => $this->request->getPost(),
                'user'     => $user,
                'roles'    => $db->table('roles')->get()->getResult(),
                'userRole' => $userRole,
            ]);
        }

        $update = [
            'name'   => $this->request->getPost('name'),
            'email'  => $this->request->getPost('email'),
            'phone'  => $this->request->getPost('phone'),
            'status' => $this->request->getPost('status'),
        ];

        $password = $this->request->getPost('password');
        if (!empty($password)) {
            $update['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $this->user->update($id, $update);

        // Update role
        $db->table('user_roles')->where('user_id', $id)->delete();
        $db->table('user_roles')->insert(['user_id' => $id, 'role_id' => $this->request->getPost('role_id')]);

        $this->audit->log('ubah_pengguna', "Mengubah pengguna ID {$id}", 'users', $id);

        return redirect()->to('/admin/pengguna')->with('success', 'Pengguna berhasil diperbarui.');
    }

    public function toggleStatus($id)
    {
        $user = $this->user->find($id);
        if (!$user) return redirect()->back()->with('error', 'Pengguna tidak ditemukan.');

        if ($user->id === session()->get('user_id')) {
            return redirect()->back()->with('error', 'Tidak bisa menonaktifkan akun sendiri.');
        }

        $newStatus = $user->status === 'active' ? 'inactive' : 'active';
        $this->user->update($id, ['status' => $newStatus]);
        $this->audit->log('ubah_status_pengguna', "Status pengguna {$user->username} → {$newStatus}", 'users', $id);

        return redirect()->back()->with('success', "Status pengguna diubah menjadi: {$newStatus}");
    }
}
