# Product Requirements Document (PRD)

## Aplikasi Posyandu Digital

**Versi dokumen:** 1.0\
**Tanggal:** 19 Oktober 2026\
**Status:** Draf untuk perencanaan dan pengembangan\
**Platform:** Website responsif\
**Framework:** CodeIgniter 4\
**Database:** MySQL

------------------------------------------------------------------------

## 1. Ringkasan Produk

Aplikasi Posyandu Digital adalah sistem berbasis website untuk membantu
kader, petugas kesehatan, dan administrator mengelola kegiatan pelayanan
Posyandu secara terstruktur. Sistem mendukung pendataan sasaran,
pencatatan kunjungan, pemantauan pertumbuhan balita, pencatatan layanan
ibu hamil dan kelompok sasaran lain sesuai jenis layanan Posyandu, serta
penyusunan laporan.

Aplikasi ini ditujukan untuk mengurangi ketergantungan pada pencatatan
manual, memudahkan pencarian riwayat pelayanan, mengurangi antrean dan
duplikasi data, serta meningkatkan kelengkapan dan konsistensi
pencatatan. Aplikasi berfungsi sebagai alat bantu administrasi dan
dokumentasi, bukan pengganti penilaian klinis tenaga kesehatan.

## 2. Latar Belakang dan Masalah

Pengelolaan Posyandu yang masih mengandalkan buku atau formulir kertas
dapat menimbulkan sejumlah kendala:

1.  Data sasaran dan hasil pelayanan tersebar di beberapa buku atau
    formulir.
2.  Pencarian riwayat kunjungan dan pertumbuhan membutuhkan waktu.
3.  Antrean dan alur pelayanan sulit dipantau secara langsung.
4.  Data pengukuran atau pelayanan berisiko tidak lengkap, tidak
    terbaca, atau terlambat direkap.
5.  Rekapitulasi laporan bulanan membutuhkan pekerjaan manual dan
    berulang.
6.  Pengawasan perubahan data dan pembatasan akses belum tentu
    terdokumentasi dengan baik.

Aplikasi dirancang untuk membantu mengatasi masalah tersebut melalui
pencatatan terpusat, validasi isian, pengelolaan alur kunjungan, dan
pembuatan laporan.

## 3. Tujuan Produk

-   Mendigitalisasi pendataan sasaran dan pencatatan kegiatan Posyandu.
-   Mempermudah petugas menemukan identitas serta riwayat pelayanan
    sasaran.
-   Membantu mengatur antrean dan tahapan pelayanan pada hari kegiatan.
-   Meningkatkan kelengkapan, keterbacaan, dan konsistensi data.
-   Mempercepat rekapitulasi dan penyusunan laporan.
-   Menyediakan pengaturan hak akses dan jejak audit untuk menjaga
    kerahasiaan serta akuntabilitas data.

### 3.1 Indikator Keberhasilan

Target numerik berikut merupakan target awal dan perlu disepakati
setelah pengukuran kondisi awal:

-   Minimal 90% catatan kunjungan yang diselesaikan memenuhi komponen
    wajib yang berlaku.
-   Waktu pencarian riwayat sasaran lebih singkat dibandingkan proses
    manual.
-   Laporan periode dapat dibuat melalui sistem tanpa menghitung ulang
    seluruh data secara manual.
-   Seluruh akses pengguna tercatat, dan perubahan penting dapat
    ditelusuri.
-   Duplikasi data sasaran dan kesalahan pengisian berkurang
    dibandingkan kondisi awal.

## 4. Pengguna dan Hak Akses

Akses diberikan berdasarkan tugas, kebutuhan kerja, kebijakan pengelola
Posyandu, serta ketentuan yang berlaku. Pengguna hanya boleh melihat
atau mengubah data yang diperlukan untuk tugasnya.

  -----------------------------------------------------------------------
  Peran                               Tanggung jawab dan akses utama
  ----------------------------------- -----------------------------------
  Administrator                       Mengelola akun, peran, konfigurasi,
                                      data master, periode kegiatan, dan
                                      pemantauan audit. Akses ke data
                                      kesehatan dibatasi sesuai kebutuhan
                                      dan kebijakan.

  Kader Posyandu                      Mendaftarkan atau memperbarui data
                                      sasaran sesuai kewenangan, mencatat
                                      kehadiran, mengelola antrean, dan
                                      memasukkan data layanan yang
                                      menjadi tanggung jawabnya.

  Petugas pengukuran                  Mencatat berat badan,
                                      panjang/tinggi badan, lingkar
                                      lengan atau pengukuran lain yang
                                      digunakan Posyandu, termasuk
                                      tanggal dan satuan.

  Tenaga kesehatan                    Meninjau data yang relevan,
                                      mencatat hasil pemeriksaan atau
                                      tindak lanjut sesuai kewenangan
                                      profesi, serta memberi arahan
                                      rujukan bila diperlukan.

  Petugas gizi/KIA/imunisasi (bila    Mencatat layanan sesuai bidang dan
  terlibat)                           kewenangan, termasuk edukasi atau
                                      tindak lanjut yang relevan.

  Koordinator/Pengelola Posyandu      Memantau kegiatan, meninjau
                                      kelengkapan data, dan mengakses
                                      laporan sesuai penugasan.

  Pimpinan/pemangku kepentingan yang  Melihat laporan agregat atau data
  berwenang                           yang secara sah diperlukan untuk
                                      pemantauan.
  -----------------------------------------------------------------------

**Catatan:** Susunan peran dapat disesuaikan dengan struktur layanan
setempat. Jangan memberikan akses luas hanya karena pengguna memiliki
jabatan administratif.

## 5. Ruang Lingkup

### 5.1 Termasuk dalam ruang lingkup

-   Pengelolaan akun dan hak akses.
-   Pendataan sasaran dan identitas dasar.
-   Pengelolaan keluarga atau wali/pengasuh bila diperlukan.
-   Penjadwalan dan pengelolaan kegiatan Posyandu.
-   Registrasi kehadiran dan antrean pelayanan.
-   Pencatatan pengukuran dan hasil pelayanan sesuai kelompok sasaran.
-   Riwayat kunjungan per sasaran.
-   Validasi kelengkapan dan konsistensi isian.
-   Pencatatan tindak lanjut atau rujukan sesuai kewenangan.
-   Laporan kegiatan, cakupan, dan kelengkapan pencatatan.
-   Audit trail, pencadangan, dan pengelolaan data.

### 5.2 Di luar ruang lingkup versi awal

-   Diagnosis otomatis atau rekomendasi klinis berbasis AI.
-   Resep elektronik dan pengelolaan farmasi klinik.
-   Integrasi otomatis dengan seluruh sistem eksternal pemerintah atau
    fasilitas kesehatan.
-   Telekonsultasi atau konsultasi video.
-   Pengambilan keputusan klinis otomatis.
-   Aplikasi mobile native Android/iOS. Website tetap dirancang
    responsif untuk ponsel dan tablet.

Integrasi eksternal dapat dipertimbangkan pada fase lanjutan setelah
kebutuhan, otorisasi, standar data, dan mekanisme pertukaran data
disepakati.

## 6. Fitur dan Persyaratan Fungsional

### 6.1 Login dan Manajemen Pengguna

-   Pengguna masuk menggunakan akun individual.
-   Sistem memeriksa kredensial dan status akun.
-   Hak akses ditentukan oleh peran dan, bila dibutuhkan, cakupan
    wilayah atau Posyandu.
-   Administrator dapat membuat, mengubah, menonaktifkan, dan mengatur
    ulang akun sesuai prosedur.
-   Sistem menyediakan mekanisme keluar, batas sesi tidak aktif, dan
    pembatasan percobaan login yang mencurigakan.
-   Kata sandi disimpan dalam bentuk hash yang aman, bukan teks biasa.

**Prioritas:** Wajib (P0).

### 6.2 Data Sasaran

-   Menambahkan sasaran dengan identitas unik internal.
-   Menyimpan data dasar sesuai kelompok sasaran, misalnya bayi/balita,
    ibu hamil, ibu nifas, remaja, atau kelompok lain yang dilayani.
-   Mencatat wali/pengasuh dan informasi kontak bila diperlukan.
-   Mencari sasaran berdasarkan nama, nomor identitas internal, tanggal
    lahir, atau kriteria yang diizinkan.
-   Memberi peringatan jika ditemukan kemungkinan data ganda.
-   Memperbarui data dengan mencatat waktu dan pengguna yang melakukan
    perubahan.
-   Menandai data tidak aktif tanpa menghapus riwayat pelayanan yang
    perlu dipertahankan.

**Prioritas:** Wajib (P0).

### 6.3 Jadwal dan Kegiatan Posyandu

-   Membuat kegiatan dengan tanggal, waktu, lokasi, dan petugas
    penanggung jawab.
-   Menampilkan daftar sasaran terdaftar dan kehadiran untuk kegiatan
    tertentu.
-   Menyimpan status kegiatan, misalnya direncanakan, berlangsung, dan
    selesai.
-   Memungkinkan pencarian kegiatan berdasarkan periode dan lokasi.

**Prioritas:** Wajib (P0).

### 6.4 Registrasi dan Antrean

-   Mendaftarkan kedatangan sasaran pada kegiatan.
-   Menghasilkan nomor antrean untuk setiap kunjungan.
-   Menampilkan status antrean, misalnya menunggu, sedang dilayani,
    selesai, atau batal.
-   Memungkinkan petugas memanggil antrean berikutnya sesuai alur yang
    ditetapkan.
-   Mencatat waktu registrasi dan perubahan status.
-   Menghindari pembuatan antrean ganda untuk sasaran yang sama pada
    kegiatan yang sama, kecuali ada alasan dan kewenangan yang jelas.

**Prioritas:** Wajib (P0).

### 6.5 Pencatatan Pengukuran dan Pelayanan

-   Menyediakan formulir sesuai kelompok sasaran dan jenis pelayanan.
-   Mencatat nilai pengukuran, satuan, tanggal/waktu, dan petugas
    pencatat.
-   Untuk bayi/balita, mendukung pencatatan berat badan, panjang/tinggi
    badan, dan pengukuran lain yang digunakan dalam prosedur setempat.
-   Untuk ibu hamil atau kelompok lain, menampilkan komponen hanya jika
    sesuai dengan jenis layanan dan kewenangan petugas.
-   Memvalidasi format, satuan, rentang nilai yang masuk akal, serta
    kolom wajib. Peringatan nilai tidak biasa tidak boleh otomatis
    dianggap sebagai diagnosis.
-   Menyediakan catatan edukasi, tindak lanjut, atau rujukan jika
    relevan.
-   Memungkinkan penyimpanan draf dan penyelesaian catatan.
-   Membatasi koreksi catatan yang telah difinalisasi sesuai prosedur;
    koreksi harus meninggalkan jejak audit.

**Prioritas:** Wajib (P0).

### 6.6 Riwayat Sasaran

-   Menampilkan daftar kunjungan sebelumnya berdasarkan tanggal.
-   Menampilkan pengukuran dan layanan yang pernah dicatat.
-   Menyediakan tampilan tren pertumbuhan bila data dan metode
    interpretasi yang sah tersedia.
-   Menampilkan tindak lanjut atau rujukan yang pernah dicatat.
-   Membatasi riwayat sesuai hak akses pengguna.
-   Menandai data yang belum lengkap atau belum diverifikasi.

**Prioritas:** Wajib (P0).

### 6.7 Validasi Kelengkapan Data

-   Menentukan komponen wajib berdasarkan jenis sasaran, kegiatan, dan
    layanan.
-   Memberi penanda untuk kolom yang belum diisi, format yang salah,
    atau data yang perlu ditinjau.
-   Menampilkan status catatan: draf, belum lengkap, lengkap, atau
    dikoreksi.
-   Mencegah penyelesaian catatan apabila komponen wajib belum dipenuhi,
    kecuali tersedia mekanisme pengecualian yang sah dengan alasan.
-   Menyediakan daftar catatan yang perlu dilengkapi untuk petugas
    berwenang.

**Prioritas:** Wajib (P0).

### 6.8 Laporan dan Rekapitulasi

-   Menyediakan laporan jumlah sasaran terdaftar dan kunjungan per
    periode.
-   Menampilkan jumlah kehadiran, layanan yang tercatat, serta catatan
    lengkap dan belum lengkap.
-   Menyediakan rekap berdasarkan tanggal, kegiatan, kelompok sasaran,
    dan Posyandu sesuai hak akses.
-   Mendukung ekspor ke CSV atau format lain yang disetujui dan
    diperlukan.
-   Menampilkan waktu pembuatan laporan dan parameter filter.
-   Mengutamakan data agregat untuk kebutuhan pemantauan; ekspor data
    identitas dibatasi dan dicatat.

**Prioritas:** Wajib (P0) untuk laporan dasar; format lanjutan dapat
menjadi P1.

### 6.9 Audit Trail

-   Mencatat login penting, pembuatan, perubahan, koreksi, penonaktifan,
    ekspor, dan tindakan penting lainnya.
-   Mencatat identitas pengguna, waktu, jenis tindakan, dan objek yang
    terpengaruh.
-   Melindungi log agar tidak dapat diubah oleh pengguna biasa.
-   Membatasi akses log kepada peran yang berwenang.
-   Tidak mencatat kata sandi atau rahasia autentikasi ke dalam log.

**Prioritas:** Wajib (P0).

## 7. Alur Utama Pengguna

1.  Administrator menyiapkan akun, peran, data master, dan jadwal
    kegiatan.
2.  Kader membuka kegiatan yang sedang berlangsung.
3.  Kader mencari sasaran yang sudah terdaftar atau mendaftarkan sasaran
    baru.
4.  Sistem memeriksa kemungkinan data ganda dan membuat catatan
    kehadiran serta nomor antrean.
5.  Petugas memanggil sasaran dan mencatat layanan sesuai tugasnya.
6.  Sistem memvalidasi komponen wajib dan memberi peringatan atas data
    yang perlu diperiksa.
7.  Petugas melengkapi dan menyelesaikan catatan sesuai kewenangan.
8.  Koordinator meninjau kelengkapan dan membuat laporan periode.
9.  Sistem menyimpan jejak audit atas tindakan penting.

## 8. Persyaratan Nonfungsional

### 8.1 Kemudahan Penggunaan

-   Antarmuka berbahasa Indonesia dengan istilah yang mudah dipahami.
-   Formulir dikelompokkan berdasarkan alur pelayanan.
-   Dapat digunakan melalui komputer, tablet, dan ponsel.
-   Pesan kesalahan menjelaskan masalah dan cara memperbaikinya.
-   Ukuran tombol dan elemen formulir memadai untuk penggunaan di
    lapangan.

### 8.2 Kinerja

-   Halaman utama dan pencarian sasaran ditargetkan merespons dalam 3
    detik pada kondisi jaringan dan beban yang disepakati.
-   Sistem harus mendukung jumlah pengguna dan volume data sesuai
    estimasi operasional.
-   Proses laporan besar dapat dijalankan dengan indikator proses atau
    mekanisme latar belakang jika diperlukan.

### 8.3 Ketersediaan dan Pemulihan

-   Menyediakan pencadangan database terjadwal.
-   Prosedur pemulihan data diuji secara berkala.
-   Target RPO dan RTO ditetapkan bersama pengelola sebelum produksi.
-   Kegagalan jaringan atau server harus menghasilkan pesan yang jelas
    dan tidak membuat pengguna mengira data telah tersimpan jika
    sebenarnya gagal.

### 8.4 Kompatibilitas

-   Berjalan pada peramban modern yang masih didukung.
-   Tampilan responsif pada desktop dan perangkat seluler.
-   Menggunakan waktu dan zona waktu yang konsisten untuk pencatatan
    kegiatan.

## 9. Teknologi dan Arsitektur

-   **Jenis aplikasi:** Website responsif dengan arsitektur sisi server.
-   **Framework backend:** CodeIgniter 4.
-   **Database:** MySQL.
-   **Antarmuka:** HTML, CSS, JavaScript, dan komponen antarmuka yang
    sesuai kebutuhan.
-   **Autentikasi dan otorisasi:** Login dengan kontrol akses berbasis
    peran serta pemeriksaan izin pada setiap endpoint yang relevan.
-   **Penyimpanan:** Database relasional dengan relasi dan indeks sesuai
    kebutuhan.
-   **Lingkungan:** Pengembangan, pengujian/staging, dan produksi
    dipisahkan.

### 9.1 Entitas Data Awal

Entitas berikut adalah rancangan konseptual dan perlu disempurnakan saat
desain database:

-   `users`
-   `roles`
-   `permissions`
-   `user_roles` atau struktur peran yang dipilih
-   `posyandu`
-   `kegiatan_posyandu`
-   `sasaran`
-   `wali_pengasuh`
-   `kunjungan`
-   `antrean`
-   `pengukuran`
-   `catatan_pelayanan`
-   `tindak_lanjut`
-   `rujukan`
-   `validasi_catatan`
-   `audit_logs`

Setiap tabel perlu memiliki kunci yang sesuai, aturan relasi, validasi,
serta kolom waktu pembuatan/perubahan bila relevan. Data sensitif tidak
boleh disalin ke tabel atau log yang tidak memerlukannya.

## 10. Keamanan, Privasi, dan Kepatuhan

-   Hak akses diberikan berdasarkan prinsip *least privilege* (akses
    minimum sesuai tugas).
-   Seluruh komunikasi melalui jaringan menggunakan HTTPS/TLS.
-   Kata sandi disimpan menggunakan mekanisme hashing yang sesuai;
    jangan menyimpan kata sandi dalam bentuk asli.
-   Enkripsi data saat tersimpan diterapkan untuk data atau media
    penyimpanan yang sesuai dengan analisis risiko dan kemampuan
    infrastruktur.
-   Validasi input dan perlindungan terhadap SQL injection, XSS, CSRF,
    serta serangan sesi diterapkan mengikuti praktik aman CodeIgniter 4.
-   Sesi pengguna dikelola dengan aman dan akun yang tidak lagi
    berwenang dapat dinonaktifkan.
-   Akses, koreksi, dan ekspor data sensitif dicatat.
-   Pencadangan dienkripsi atau dilindungi setara dengan data utama dan
    aksesnya dibatasi.
-   Kebijakan retensi, koreksi, penghapusan, dan pembagian data
    ditetapkan oleh pengelola sesuai ketentuan yang berlaku.
-   Data hanya dikumpulkan sesuai tujuan pelayanan; data untuk laporan
    publik sebaiknya diagregasi atau dianonimkan.
-   Pengujian keamanan dilakukan sebelum peluncuran dan setelah
    perubahan besar.

Penerapan harus ditinjau terhadap peraturan Indonesia yang relevan,
termasuk ketentuan perlindungan data pribadi dan kebijakan
kesehatan/Posyandu yang berlaku. Daftar kepatuhan final perlu divalidasi
oleh pengelola dan pihak yang kompeten; dokumen ini bukan pendapat
hukum.

## 11. Aturan Bisnis

1.  Setiap sasaran memiliki identitas internal unik.
2.  Kunjungan selalu terhubung dengan sasaran dan kegiatan yang relevan.
3.  Catatan pelayanan mencatat petugas dan waktu pencatatan.
4.  Komponen wajib dapat berbeda menurut kelompok sasaran dan jenis
    layanan.
5.  Catatan yang telah diselesaikan tidak boleh diubah diam-diam;
    koreksi harus tercatat.
6.  Pengguna hanya dapat melakukan tindakan sesuai hak aksesnya.
7.  Data historis yang perlu dipertahankan tidak dihapus hanya karena
    sasaran tidak aktif.
8.  Nilai pengukuran yang tidak biasa memicu peninjauan, bukan diagnosis
    otomatis.
9.  Ekspor data identitas memerlukan hak akses dan alasan penggunaan
    yang sesuai.
10. Perubahan pada definisi formulir wajib harus memiliki versi atau
    catatan perubahan agar laporan antarperiode dapat ditafsirkan dengan
    benar.

## 12. Kriteria Penerimaan

  -----------------------------------------------------------------------
  ID                                  Kriteria penerimaan
  ----------------------------------- -----------------------------------
  AC-01                               Pengguna dapat login dan hanya
                                      melihat menu serta data sesuai hak
                                      aksesnya.

  AC-02                               Petugas dapat mencari sasaran dan
                                      sistem memberi peringatan terhadap
                                      kemungkinan duplikasi.

  AC-03                               Kader dapat membuat kegiatan,
                                      mencatat kehadiran, dan
                                      menghasilkan nomor antrean.

  AC-04                               Petugas dapat menyimpan pengukuran
                                      dan catatan pelayanan dengan satuan
                                      serta waktu yang jelas.

  AC-05                               Riwayat kunjungan dapat ditampilkan
                                      berdasarkan sasaran dan urutan
                                      tanggal.

  AC-06                               Sistem menandai komponen wajib yang
                                      belum diisi dan menampilkan status
                                      kelengkapan.

  AC-07                               Laporan dapat difilter berdasarkan
                                      periode dan kegiatan, serta
                                      hasilnya sesuai data tersimpan.

  AC-08                               Tindakan penting dan koreksi
                                      tercatat dalam audit trail.

  AC-09                               Pengguna tanpa izin tidak dapat
                                      mengakses data melalui URL atau
                                      permintaan langsung.

  AC-10                               Proses pencadangan dan pemulihan
                                      diuji dan didokumentasikan sebelum
                                      sistem digunakan secara
                                      operasional.
  -----------------------------------------------------------------------

## 13. Prioritas Pengembangan

### Fase 1 --- MVP

-   Login dan hak akses.
-   Data sasaran.
-   Jadwal/kegiatan Posyandu.
-   Kehadiran dan antrean.
-   Pencatatan pengukuran/pelayanan dasar.
-   Riwayat sasaran.
-   Validasi kelengkapan.
-   Laporan dasar.
-   Audit trail dan pencadangan.

### Fase 2 --- Penyempurnaan

-   Visualisasi tren pertumbuhan sesuai standar yang disetujui.
-   Laporan dan ekspor yang lebih fleksibel.
-   Pengingat kegiatan atau tindak lanjut.
-   Dukungan penggunaan pada jaringan yang kurang stabil, bila kebutuhan
    dan desain keamanan memungkinkan.
-   Integrasi dengan sistem eksternal setelah persyaratan teknis dan
    kewenangan disepakati.

## 14. Risiko dan Mitigasi

  -----------------------------------------------------------------------
  Risiko                  Dampak                  Mitigasi
  ----------------------- ----------------------- -----------------------
  Kader belum terbiasa    Pencatatan lambat atau  Pelatihan, panduan
  menggunakan aplikasi    tidak konsisten         singkat, uji coba, dan
                                                  desain sederhana

  Jaringan internet tidak Data terlambat atau     Indikator status
  stabil                  gagal tersimpan         simpan, penanganan
                                                  kegagalan yang jelas,
                                                  dan evaluasi opsi
                                                  operasional saat
                                                  offline

  Data ganda atau salah   Riwayat terpecah atau   Identitas unik,
  identitas               tertukar                pencarian sebelum
                                                  pendaftaran, dan proses
                                                  penggabungan yang
                                                  terkontrol

  Data kesehatan diakses  Risiko privasi          Hak akses minimum,
  tanpa izin                                      HTTPS, audit trail,
                                                  peninjauan akses, dan
                                                  prosedur insiden

  Isian tidak lengkap     Laporan tidak akurat    Validasi kolom wajib,
                                                  daftar tindak lanjut,
                                                  dan pemantauan
                                                  kelengkapan

  Data hilang atau rusak  Gangguan pelayanan dan  Backup terjadwal,
                          kehilangan riwayat      pembatasan akses, dan
                                                  uji pemulihan
  -----------------------------------------------------------------------

## 15. Asumsi dan Hal yang Perlu Diputuskan

Sebelum pengembangan, pemilik produk perlu memastikan:

-   Jenis Posyandu dan kelompok sasaran yang akan dicakup.
-   Formulir dan komponen wajib untuk tiap layanan.
-   Struktur organisasi, peran, dan kewenangan petugas.
-   Identitas sasaran yang akan digunakan serta aturan pencocokan data.
-   Format laporan yang diwajibkan oleh pengelola atau instansi terkait.
-   Kondisi jaringan dan kebutuhan akses di lokasi.
-   Lokasi hosting, kepemilikan sistem, pengelola backup, serta target
    pemulihan.
-   Kebijakan persetujuan, privasi, retensi, koreksi, dan akses data.
-   Kebutuhan integrasi dengan sistem lain dan pihak yang berwenang
    menyetujuinya.

## 16. Definisi Selesai (*Definition of Done*)

Fitur dianggap selesai apabila kebutuhan fungsionalnya terpenuhi,
validasi dan hak akses diuji, hasil uji dicatat, pesan kesalahan
ditangani, perubahan penting tercatat dalam audit trail, dokumentasi
pengguna tersedia, dan tidak terdapat masalah kritis yang belum
diselesaikan. Sebelum peluncuran, lakukan uji penerimaan pengguna
bersama kader dan tenaga kesehatan yang akan menggunakan sistem.

------------------------------------------------------------------------

**Catatan akhir:** PRD ini merupakan draf kebutuhan produk untuk memulai
proses desain dan pengembangan. Formulir pelayanan, indikator, alur
rujukan, kebijakan data, serta kewenangan pengguna harus disesuaikan
dengan proses Posyandu setempat dan ketentuan resmi yang berlaku.
